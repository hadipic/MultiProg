#ifndef COMMONVARIABLES_H
#define COMMONVARIABLES_H

#include <QObject>
#include "HardwareLayer/usbTools.h"
#include "HardwareLayer/Devices/progAVR.h"
#include "HardwareLayer/Devices/progDevice.h"
#include "HardwareLayer/Devices/Memory/progEEPROM.h"
#include "HardwareLayer/Devices/PIC/Pic12/prog12c5xx.h"
#include "HardwareLayer/Devices/PIC/Pic12/prog12f5xx.h"
#include "HardwareLayer/Devices/PIC/pic16/prog16fxxx.h"

class GlobalVariables : public QObject
{
    Q_OBJECT
public:
    static GlobalVariables *getInstance();
    static USBTools *usb;
    static Prog12F5xx *prog12F5xx;
    static Prog12C5xx *prog12C5xx;
    static ProgEEPROM *progEEPROM;
    static Prog16Fxxx *prog16Fxxx;
private:
    explicit GlobalVariables(QObject *parent = 0);
    static GlobalVariables * globalVariables;
signals:
    
public slots:
    
};

#endif // COMMONVARIABLES_H
