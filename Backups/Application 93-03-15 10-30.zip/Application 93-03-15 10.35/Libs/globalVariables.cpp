#include "globalVariables.h"

USBTools *GlobalVariables::usb;
ProgEEPROM *GlobalVariables::progEEPROM;
Prog12C5xx *GlobalVariables::prog12C5xx;
Prog12F5xx *GlobalVariables::prog12F5xx;
Prog16Fxxx *GlobalVariables::prog16Fxxx;

GlobalVariables *GlobalVariables::globalVariables;

GlobalVariables::GlobalVariables(QObject *parent) :
    QObject(parent)
{
    usb = new USBTools();
    prog12C5xx = new Prog12C5xx(usb, this);
    prog12F5xx = new Prog12F5xx(usb, this);
    progEEPROM = new ProgEEPROM(usb, this);
    prog16Fxxx = new Prog16Fxxx(usb, this);
}


GlobalVariables *GlobalVariables::getInstance()
{
    if(globalVariables==NULL)
    {
        globalVariables = new GlobalVariables();
    }
    return globalVariables;
}

