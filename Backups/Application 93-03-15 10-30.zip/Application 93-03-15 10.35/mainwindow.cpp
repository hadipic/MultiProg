#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QString"
#include <QPixmap>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QTableView>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    connect(GlobalVariables::usb, SIGNAL(onIoChanged()), this, SLOT(onIoChanged()));
    createActions();
    createToolbars();

    GlobalVariables::usb->FindDevice();
    connect( GlobalVariables::progEEPROM, SIGNAL(onProgressChanged(int, int)),this, SLOT(on_Progress_Changed(int, int)));


    ui->wdgHexEditor->setBitLength(16);

    ui->wdgHexEditor->setSize(64*1024);
    //ui->wdgHexEditor->loadFile("E:\\Programming\\Qt\\Open Programmer\\Sample Data\\ee2.hex");
    ui->wdgHexEditor->loadFile("D:\\aplication\\qt\\Sample Data\\ee2.hex");

    /*QTableView *tv = new QTableView(this);
    QItemSelectionModel *m = tv->selectionModel();
    //QAbstractItemModel *model = new QAbstractItemModel(this);
    tv->setModel(m);
    tv->horizontalHeader()->setVisible(false);
    tv->verticalHeader()->setVisible(false);
    tv->resizeColumnsToContents();
    ui->cboMicroTypes->setView(tv);
    */
    connect(ui->wdgDevicesList, SIGNAL(onDeviceSelected(DeviceFamily*,DeviceType*,DeviceInfo*)), this, SLOT(on_DeviceSelected(DeviceFamily*,DeviceType*,DeviceInfo*)));
}

void MainWindow::createActions()
{
    newAct = new QAction(QIcon(":/images/new.png"), tr("&New"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("Create a new file"));
    connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));

    openAct = new QAction(QIcon(":/images/open.png"), tr("&Open..."), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open an existing file"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(open()));
    connect(ui->mnuOpen, SIGNAL(triggered()), this, SLOT(open()));



    saveAct = new QAction(QIcon(":/images/save.png"), tr("&Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("Save the document to disk"));
    connect(saveAct, SIGNAL(triggered()), this, SLOT(save()));

    saveAsAct = new QAction(tr("Save &As..."), this);
    saveAsAct->setShortcuts(QKeySequence::SaveAs);
    saveAsAct->setStatusTip(tr("Save the document under a new name"));
    connect(saveAsAct, SIGNAL(triggered()), this, SLOT(saveAs()));
    connect(ui->actionSave_as, SIGNAL(triggered()), this, SLOT(saveAs()));

    //! [0]
    exitAct = new QAction(tr("E&xit"), this);
    exitAct->setShortcuts(QKeySequence::Quit);
    exitAct->setStatusTip(tr("Exit the application"));
    connect(exitAct, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()));
    //! [0]

    //#ifndef QT_NO_CLIPBOARD
    cutAct = new QAction(QIcon(":/images/cut.png"), tr("Cu&t"), this);
    cutAct->setShortcuts(QKeySequence::Cut);
    cutAct->setStatusTip(tr("Cut the current selection's contents to the "
                            "clipboard"));
    connect(cutAct, SIGNAL(triggered()), this, SLOT(cut()));

    copyAct = new QAction(QIcon(":/images/copy.png"), tr("&Copy"), this);
    copyAct->setShortcuts(QKeySequence::Copy);
    copyAct->setStatusTip(tr("Copy the current selection's contents to the "
                             "clipboard"));
    connect(copyAct, SIGNAL(triggered()), this, SLOT(copy()));

    pasteAct = new QAction(QIcon(":/images/paste.png"), tr("&Paste"), this);
    pasteAct->setShortcuts(QKeySequence::Paste);
    pasteAct->setStatusTip(tr("Paste the clipboard's contents into the current "
                              "selection"));

    mnuOpen = new QAction(tr("About &Qt"), this);
    mnuOpen->setStatusTip(tr("Show the Qt library's About box"));
    connect( mnuOpen, SIGNAL(triggered()),this,  SLOT(open()));
    //! [22]


}
void MainWindow::createToolbars()
{
    ui->mainToolBar->clear();
    ui->mainToolBar->addAction( openAct);
    ui->mainToolBar->addAction(newAct);
    ui->mainToolBar->addAction( saveAct);
    ui->mainToolBar->addSeparator();
    ui->mainToolBar->addAction(cutAct);
    ui->mainToolBar->addAction(copyAct);
    ui->mainToolBar->addAction(pasteAct);

    //fileMenu = menuBar()->addMenu(tr("&File"));
    // fileMenu->addAction(newAct);

}

void MainWindow::newFile()
{
    qDebug()<<"new";

}
void MainWindow::open()
{
    qDebug()<<"open";
    // fileName = QFileDialog::getOpenFileName(this, tr("Open File"),"", tr("Files (*.hex)"));

    if (maybeSave())
    {
        QString fileName = QFileDialog::getOpenFileName(this);
        if (!fileName.isEmpty())
        {
            //ui->wdgHexEditor->setBitLength(8);
            ui->wdgHexEditor->loadFile(fileName);
            GlobalVariables::usb->memEE = ui->wdgHexEditor->buffer;
        }
    }
}


bool MainWindow::save()
{
    qDebug()<<"save";
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text)) {
        QMessageBox::warning(this, tr("Application"),
                             tr("Cannot write file %1:\n%2.")
                             .arg(fileName)
                             .arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
#ifndef QT_NO_CURSOR
    QApplication::setOverrideCursor(Qt::WaitCursor);
#endif
    out << ui->plainTextEdit->toPlainText();
#ifndef QT_NO_CURSOR
    QApplication::restoreOverrideCursor();
#endif

    setCurrentFile(fileName);
    statusBar()->showMessage(tr("File saved"), 2000);
    return true;

}




bool MainWindow::saveAs()
{
    qDebug()<<"saveAs";
    fileName = QFileDialog::getOpenFileName(this, tr("Open File"),"", tr("Files (*.hex)"));
    return save();
}

void MainWindow::on_Progress_Changed(int step, int max)
{
    ui->progressBar->setMaximum(max);
    ui->progressBar->setValue(step);
    qDebug()<<step<<max;
}



bool MainWindow::maybeSave()
//! [40] //! [41]
{
    if (ui->plainTextEdit->document()->isModified()) {
        QMessageBox::StandardButton ret;
        ret = QMessageBox::warning(this, tr("Application"),
                                   tr("The document has been modified.\n"
                                      "Do you want to save your changes?"),
                                   QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save)
            return save();
        else if (ret == QMessageBox::Cancel)
            return false;
    }
    return true;
}



void MainWindow::loadFile(const QString &fileName)
//! [42] //! [43]
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly | QFile::Text)) {
        QMessageBox::warning(this, tr("Application"),
                             tr("Cannot read file %1:\n%2.")
                             .arg(fileName)
                             .arg(file.errorString()));
        return;
    }

    QTextStream in(&file);
#ifndef QT_NO_CURSOR
    QApplication::setOverrideCursor(Qt::WaitCursor);
#endif
    ui->plainTextEdit->setPlainText(in.readAll());
#ifndef QT_NO_CURSOR
    QApplication::restoreOverrideCursor();
#endif

    setCurrentFile(fileName);
    statusBar()->showMessage(tr("File loaded"), 2000);
}


void MainWindow::setCurrentFile(const QString &fileName)
//! [46] //! [47]
{
    curFile = fileName;
    ui->plainTextEdit->document()->setModified(false);
    setWindowModified(false);

    QString shownName = curFile;
    if (curFile.isEmpty())
        shownName = "untitled.txt";
    setWindowFilePath(shownName);
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_MainWindow_toolButtonStyleChanged(const Qt::ToolButtonStyle &toolButtonStyle)
{

}



void MainWindow::on_radioButton_111_clicked()
{
    ui->grbRC7->setTitle("&RC7=1");
    GlobalVariables::usb->trisc &= 0x7f;
    GlobalVariables::usb->latac |= 0x80;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_110_clicked()
{
    ui->grbRC7->setTitle("&RC7=0");
    GlobalVariables::usb->trisc &= 0x7f;
    GlobalVariables::usb->latac &= 0x7f;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_117_clicked()
{
    ui->grbRC6->setTitle("&RC6=1");
    GlobalVariables::usb->trisc &= 0xbf;
    GlobalVariables::usb->latac |= 0x40;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_116_clicked()
{
    ui->grbRC6->setTitle("&RC6=0");
    GlobalVariables::usb->trisc &= 0xbf;
    GlobalVariables::usb->latac &= 0xbf;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_120_clicked()
{
    ui->grbRA3->setTitle("&RA3=1");
    GlobalVariables::usb->trisa &= 0xf7;
    GlobalVariables::usb->latac |= 0x08;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_123_clicked()
{
    ui->grbRA4->setTitle("&RA4=1");
    GlobalVariables::usb->trisa &=0xef;
    GlobalVariables::usb->latac |= 0x10;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_162_clicked()
{
    ui->grbRA5->setTitle("&RA5=1");
    GlobalVariables::usb->trisa &= 0xdf; // pin a5 0utput
    GlobalVariables::usb->latac |= 0x20;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_119_clicked()
{
    ui->grbRA3->setTitle("&RA3=0");
    GlobalVariables::usb->trisa &= 0xf7;
    GlobalVariables::usb->latac &= 0xf7;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_122_clicked()
{
    ui->grbRA4->setTitle("&RA4=0");
    GlobalVariables::usb->trisa &=0xef;
    GlobalVariables::usb->latac &= 0xef;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_161_clicked()
{
    ui->grbRA5->setTitle("&RA5=0");
    GlobalVariables::usb->trisa &= 0xdf; // pin a5 0utput
    GlobalVariables::usb->latac &= 0xdf;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_160_clicked()
{
    ui->grbRA5->setTitle("&RA5 IN=>");
    GlobalVariables::usb->trisa |= 0x20;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_121_clicked()
{
    ui->grbRA4->setTitle("&RA4 IN=>");
    GlobalVariables::usb->trisa |= 0x10;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_118_clicked()
{
    ui->grbRA3->setTitle("&RA3 IN=>");
    GlobalVariables::usb->trisa |= 0x08;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_109_clicked()
{
    ui->grbRC7->setTitle("&RC7 IN=>");
    GlobalVariables::usb->trisc |= 0x80;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_115_clicked()
{
    ui->grbRC6->setTitle("&RC6 IN=>");
    GlobalVariables::usb->trisc |= 0x40;
    GlobalVariables::usb->IoChange();
}










void MainWindow::on_radioButton_92_clicked()
{

    ui->grbRB1->setTitle("&RB1=0");
    GlobalVariables::usb->trisb&=0xfd; //0b11111110
    GlobalVariables::usb->latb&=0xfd;
    GlobalVariables::usb->IoChange();
}



void MainWindow::on_radioButton_95_clicked()
{
    ui->grbRB2->setTitle("&RB2=0");
    GlobalVariables::usb->trisb&=0xfb;
    GlobalVariables::usb->latb&=0xfb;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_98_clicked()
{
    ui->grbRB3->setTitle("&RB3=0");
    GlobalVariables::usb->trisb&=0xf7;
    GlobalVariables::usb->latb&=0xf7;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_101_clicked()
{
    ui->grbRB4->setTitle("&RB4=0");
    GlobalVariables::usb->trisb&=0xef;
    GlobalVariables::usb->latb&=0xef;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_104_clicked()
{
    ui->grbRB5->setTitle("&RB5=0");
    GlobalVariables::usb->trisb&=0xdf;
    GlobalVariables::usb->latb&=0xdf;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_107_clicked()
{
    ui->grbRB6->setTitle("&RB6=0");
    GlobalVariables::usb->trisb&=0xbf;
    GlobalVariables::usb->latb&=0xbf;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_113_clicked()
{
    ui->grbRB7->setTitle("&RB7=0");
    GlobalVariables::usb->trisb&=0x7f;
    GlobalVariables::usb->latb&=0x7f;
    GlobalVariables::usb->IoChange();
}




void MainWindow::on_radioButton_89_clicked()
{
    ui->grbRB0->setTitle("&RB0=0");
    GlobalVariables::usb->trisb&=0b11111110;
    GlobalVariables::usb->latb&=0b11111110;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_90_clicked()
{
    ui->grbRB0->setTitle("&RB0=1");
    GlobalVariables::usb->trisb&=0b11111110;
    GlobalVariables::usb->latb|=0b00000001;
    GlobalVariables::usb->IoChange();

}

void MainWindow::on_radioButton_88_clicked()
{
    ui->grbRB0->setTitle("&RB0 IN=>");
    GlobalVariables::usb->trisb |= 0b00000001;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_93_clicked()
{
    ui->grbRB1->setTitle("&RB1=1");
    GlobalVariables::usb->trisb&=0xfd;
    GlobalVariables::usb->latb |= 0x02;
    GlobalVariables::usb->IoChange();
}





void MainWindow::on_radioButton_96_clicked()
{
    ui->grbRB2->setTitle("&RB2=1");
    GlobalVariables::usb->trisb&=0xfb;
    GlobalVariables::usb->latb |= 0x04;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_99_clicked()
{
    ui->grbRB3->setTitle("&RB3=1");
    GlobalVariables::usb->trisb&=0xf7;
    GlobalVariables::usb->latb |= 0x08;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_102_clicked()
{
    ui->grbRB4->setTitle("&RB4=1");
    GlobalVariables::usb->trisb&=0xef;
    GlobalVariables::usb->latb |= 0x10;
    GlobalVariables::usb->IoChange();

}

void MainWindow::on_radioButton_105_clicked()
{
    ui->grbRB5->setTitle("&RB5=1");
    GlobalVariables::usb->trisb&=0xdf;
    GlobalVariables::usb->latb |= 0x20;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_108_clicked()
{
    ui->grbRB6->setTitle("&RB6=1");
    GlobalVariables::usb->trisb&=0xbf;
    GlobalVariables::usb->latb |= 0x40;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_114_clicked()
{
    ui->grbRB7->setTitle("&RB7=1");
    GlobalVariables::usb->trisb&=0x7f;
    GlobalVariables::usb->latb |= 0x80;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_112_clicked()
{
    ui->grbRB7->setTitle("&RB7 IN=>");
    GlobalVariables::usb->trisb |= 0x80;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_106_clicked()
{
    ui->grbRB6->setTitle("&RB6 IN=>");
    GlobalVariables::usb->trisb |= 0x40;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_103_clicked()
{
    ui->grbRB5->setTitle("&RB5 IN=>");
    GlobalVariables::usb->trisb |= 0x20;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_100_clicked()
{
    ui->grbRB4->setTitle("&RB4 IN=>");
    GlobalVariables::usb->trisb |= 0x10;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_97_clicked()
{
    ui->grbRB3->setTitle("&RB3 IN=>");
    GlobalVariables::usb->trisb |= 0x08;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_94_clicked()
{
    ui->grbRB2->setTitle("&RB2 IN=>");
    GlobalVariables::usb->trisb |= 0x04;
    GlobalVariables::usb->IoChange();
}

void MainWindow::on_radioButton_91_clicked()
{
    ui->grbRB1->setTitle("&RB1 IN=>");
    GlobalVariables::usb->trisb |= 0x02;
    GlobalVariables::usb->IoChange();
}

void MainWindow::onIoChanged()
{
    // qDebug()<<"port A:"<<QString::number(GlobalVariables::usb->portA.byte, 2)<<"port B:"<< QString::number(GlobalVariables::usb->portB.byte, 2)<<"port C:"<< QString::number(GlobalVariables::usb->portC.byte, 2);
    if(ui->radioButton_88->isChecked() ) ui->grbRB0->setTitle(QString("&RB0 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit0));
    if(ui->radioButton_91->isChecked() ) ui->grbRB1->setTitle(QString("&RB1 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit1));
    if(ui->radioButton_94->isChecked() ) ui->grbRB2->setTitle(QString("&RB2 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit2));
    if(ui->radioButton_97->isChecked() ) ui->grbRB3->setTitle(QString("&RB3 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit3));
    if(ui->radioButton_100->isChecked() ) ui->grbRB4->setTitle(QString("&RB4 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit4));
    if(ui->radioButton_113->isChecked() ) ui->grbRB5->setTitle(QString("&RB5 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit5));
    if(ui->radioButton_106->isChecked() ) ui->grbRB6->setTitle(QString("&RB6 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit6));
    if(ui->radioButton_112->isChecked() )  ui->grbRB7->setTitle(QString("&RB7 IN=>")+ QString::number(GlobalVariables::usb->portB.bits.Bit7));

    if(ui->radioButton_115->isChecked() ) ui->grbRC6->setTitle(QString("&RC6 IN=>")+ QString::number(GlobalVariables::usb->portC.bits.Bit6));
    if(ui->radioButton_109->isChecked() ) ui->grbRC7->setTitle(QString("&RC7 IN=>")+ QString::number(GlobalVariables::usb->portC.bits.Bit7));


    if(ui->radioButton_118->isChecked() ) ui->grbRA3->setTitle(QString("&RA3 IN=>")+ QString::number(GlobalVariables::usb->portA.bits.Bit3));
    if(ui->radioButton_121->isChecked() ) ui->grbRA4->setTitle(QString("&RA4 IN=>")+ QString::number(GlobalVariables::usb->portA.bits.Bit4));
    if(ui->radioButton_160->isChecked() ) ui->grbRA5->setTitle(QString("&RA5 IN=>")+ QString::number(GlobalVariables::usb->portA.bits.Bit5));


    // qDebug()<<"adc:"<<QString::number(GlobalVariables::usb->StartHVReg(ui->horizontalSlider->value())/72, 10) ;


    if(ui->chb_dctodc->checkState()) qDebug()<<"slider:"<<QString::number(ui->horizontalSlider->value(), 10) ;
    GlobalVariables::usb->DCDCactive(ui->chb_dctodc->checkState(),ui->horizontalSlider->value());

    float vpp_v = GlobalVariables::usb->StartHVReg(ui->horizontalSlider->value())/72.28;
    QString show = QString::number(vpp_v, 'g', 3); // show foloting number
    ui->label_adc->setText(QString("VPP Voltage=")+show);

    GlobalVariables::usb->vdd_vpp(ui->ch_B_vpp->isChecked(),ui->ch_B_vcc->isChecked());



}



void MainWindow::on_grbEnbableIo_clicked(bool checked)
{
    GlobalVariables::usb->changeEnableIo(checked);
}

void MainWindow::on_io_chek_currentChanged(int index)
{
    GlobalVariables::usb->changeEnableIo(index==3 && ui->grbEnbableIo->isChecked());
}

void MainWindow::on_btnRead_clicked()
{
    //GlobalVariables::progEEPROM->ReadI2C(0x10000, 2);
    deviceInfo->readWriteInfo->read(0x10000, 2);
    return;
    qint32   i,j;
    QString str;
    for(i=0;i<0x100;i++)
    {
        str.append(GlobalVariables::usb->memEE[i]);
    }
    qDebug()<<str;
    //ui->plainTextEdit->setColor(QColor(255,0,0));
    ui->plainTextEdit->insertPlainText(str);
}

void MainWindow::on_btnWrite_clicked()
{
    //ui->stackedWidget->setCurrentIndex(0);
    //GlobalVariables::progEEPROM->WriteI2C(32*1024,1,128);
    deviceInfo->readWriteInfo->write(0x10000);
}

void MainWindow::on_DeviceSelected(DeviceFamily *family, DeviceType *type, DeviceInfo *deviceInfo)
{
    this->deviceFamily=family;
    this->deviceType=type;
    this->deviceInfo=deviceInfo;
    qDebug()<<family->familyName<<type->typeName<<deviceInfo->name;
}
