#ifndef USBTOOLS_H
#define USBTOOLS_H

#include <QObject>
#include <QString>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <getopt.h>
#include <string.h>
#include "strings.h"
#include "instructions.h"
#include "basetsd.h"
#include "windef.h"
#include "wtypes.h"
#include "winbase.h"
#include "winreg.h"
#include "wingdi.h"
#include "winuser.h"
#include "setupapi.h"
#include <QTimer>
#include "QDebug"

struct Bits
{
    quint8 Bit0:1;
    quint8 Bit1:1;
    quint8 Bit2:1;
    quint8 Bit3:1;
    quint8 Bit4:1;
    quint8 Bit5:1;
    quint8 Bit6:1;
    quint8 Bit7:1;
};
union Port
{
    quint8 byte;
    Bits bits;
};

class USBTools : public QObject
{
    Q_OBJECT


public:


#define COL 16
#define VERSION "0.8.1"
#define G (12.0/34*1024/5)		//=72,2823529412
#define LOCK	1
#define FUSE	2
#define FUSE_H  4
#define FUSE_X	8
#define CAL 	16
#define SLOW	256

    explicit USBTools(QObject *parent = 0);

    int vid;
    int pid;
    char unsigned bufferU[128], bufferI[128];
    int trisa, trisb, trisc, latac, latb;
    int DIMBUF;
    int HwID=0;
    Port portA, portB, portC;
    bool saveLog;
    int FWVersion;

    HANDLE WriteHandle,ReadHandle;
    HANDLE hEventObject;
    OVERLAPPED HIDOverlapped;
    DWORD BytesWritten, NumberOfBytesRead;
    int max_err;

    void Write();
    int  FindDevice();
    void PrintMessage(QString msg);
    void WriteSample();
    void Connect();
    void DCDCactive(bool checkdcdc ,qint8 valuedc);
    int  StartHVReg(double V);
    void  vdd_vpp (bool vpp_e , bool vcc_e);
    //void I2cspiR();
    //void I2cspiS();
    //void ProgID();
    //void PrintMessageI2C(const char *msg);
    //void ShowContext();

    //void TestHw();
    int  CheckS1();
    void read();
    void msDelay(double delay);
    void IoChange();
    QString toBinary(quint32 a);

    bool isDeviceDetected();

    void changeEnableIo(bool canChanged);
    unsigned char *memEE;
signals:
    void onIoChanged();
    

public slots:
    void updateIo();


private:
    //void timerEvent(QTimerEvent *event);
    QTimer *timer;
    bool _isDeviceDetected;
};

#endif // USBTOOLS_H
