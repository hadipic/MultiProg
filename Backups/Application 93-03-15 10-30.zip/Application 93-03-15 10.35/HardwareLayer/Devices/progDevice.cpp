#include "progDevice.h"

ProgDevice::ProgDevice(USBTools *usb, QObject *parent)
{
    this->usb=usb;
}


void ProgDevice::read(int a, int b, int c, int d)
{
    qDebug()<<"ProgDevice Read"<<a<<b<<c<<d;
}

void ProgDevice::write(int a, int b, int c, int d, int e, int f)
{
    qDebug()<<"ProgDevice Write"<<a<<b<<c<<d<<e<<f;
}

