#include "devices.h"

DeviceFamily *Devices::addDeviceFamily(QString familyName, QString companyName)
{
    DeviceFamily *deviceFamily = new DeviceFamily();
    deviceFamily ->familyName = familyName;
    deviceFamily ->companyName = companyName;
    deviceFamilyList.append(deviceFamily);
    return deviceFamily;
}

DeviceType *DeviceFamily::addDeviceType(QString typeName)
{
    DeviceType * deviceType = new DeviceType();
    deviceType->typeName=typeName;
    deviceTypesList.append(deviceType);
    return deviceType;
}

DeviceInfo * DeviceType::addDevice(QString deviceName, ReadWriteInfo *readWriteInfo)
{
    DeviceInfo  *device = new DeviceInfo();
    device->name= deviceName;
    device->readWriteInfo=readWriteInfo;
    devicesList.append(device);
    //allDevicesList.append(device);
    return device;
}

ReadWriteInfo::ReadWriteInfo()
{
}

ReadWriteInfo::ReadWriteInfo(ProgDevice *readClass,ProgDevice *writeClass, double HV, int V33, int memoryFlashSize, int memoryEESize,
                             QList<int> ReadParam, int ResArea, QList<int> WriteParam, double WriteParamD)
{
    this->ReadClass=readClass;
    this->WriteClass = writeClass;
    this->HV = HV;
    this->V33=V33;
    this->memoryFlashSize = memoryFlashSize;
    this->memoryEESize=memoryEESize;
    this->ReadParam=ReadParam;
    this->ResArea=ResArea;
    this->WriteParam=WriteParam;
    this->WriteParamD;
}

void ReadWriteInfo::read(int ee, int r)
{
    int readParam[2]={0};
    for (int i = 0; i < this->ReadParam.length(); ++i)
        readParam[i]=this->ReadParam[i];
    ReadClass->read(memoryFlashSize, memoryEESize, readParam[0], readParam[1]);

}

void ReadWriteInfo::write(int ee)
{
    int writeParam[4]={0};
    for (int i = 0; i < this->WriteParam.length(); ++i)
        writeParam[i]=this->WriteParam[i];
    WriteClass->write(memoryFlashSize, memoryEESize, writeParam[0], writeParam[1], writeParam[2], writeParam[3]);
}

Devices::Devices(QObject *parent) :
    QObject(parent)
{
    //ReadPtr(10,5);
    DeviceFamily *PIC = addDeviceFamily("PIC", "MicroChip");
    DeviceFamily *AVR = addDeviceFamily("AVR", "ATMEL");
    DeviceFamily *Memory = addDeviceFamily("Memory", "Standard");
    DeviceFamily *OneWire = addDeviceFamily("Onw Wire", "Standard");


    DeviceType *typePIC10F=PIC->addDeviceType("PIC 10F");
    DeviceType *typePIC12F=PIC->addDeviceType("PIC 12F");
    DeviceType *typePIC16F=PIC->addDeviceType("PIC 16F");
    DeviceType *typePIC18F=PIC->addDeviceType("PIC 18F");
    DeviceType *typePIC24CF=PIC->addDeviceType("PIC 24CF");
    DeviceType *typePIC24CH=PIC->addDeviceType("PIC 24CH");
    DeviceType *typePIC24EP=PIC->addDeviceType("PIC 24EP");
    DeviceType *typePIC30F=PIC->addDeviceType("PIC 30F");
    DeviceType *typePIC33F=PIC->addDeviceType("PIC 33F");
    DeviceType *typePIC33EP=PIC->addDeviceType("PIC 33EP");


    DeviceType *typeAVRAT90=AVR->addDeviceType("ATMEL AT90");
    DeviceType *typeAVRATmega=AVR->addDeviceType("ATMEL ATmega");
    DeviceType *typeAVRATtiny=AVR->addDeviceType("ATMEL ATtiny");

    DeviceType *typeI2C24C=Memory->addDeviceType("I2C 24C");
    DeviceType *typeFlash25=Memory->addDeviceType("Flash 25");
    DeviceType *typeSPI93=Memory->addDeviceType("SPI 93");
    DeviceType *typeSPI95=Memory->addDeviceType("SPI 95");

    DeviceType *typeOneWireDS=OneWire->addDeviceType("OneWire DS");
    DeviceType *typeOneWire11=OneWire->addDeviceType("OneWire 11");


    ReadWriteInfo  *group1=new ReadWriteInfo(

                GlobalVariables::prog12F5xx,
                GlobalVariables::prog12F5xx,
                13.0,0,
                0x100,5, QList<int>(), 0x40, QList<int>()<<0xFF,0);



    typePIC10F->addDevice("10F200", group1);
    typePIC10F->addDevice("10F204", group1);
    typePIC10F->addDevice("10F220", group1);

    typePIC10F->devicesList[0]->readWriteInfo->read(0,0);
    typePIC10F->devicesList[0]->readWriteInfo->write(0);

    ReadWriteInfo  *group2=new ReadWriteInfo(
                GlobalVariables::prog12F5xx,
                GlobalVariables::prog12C5xx,
                13.0,0,
                0x200,4, QList<int>(), 0x40, QList<int>(),0);
    typePIC12F->addDevice("12C508", group2);
    typePIC12F->addDevice("12C508A", group2);


    ReadWriteInfo  *group3=new ReadWriteInfo(
                GlobalVariables::prog12F5xx,
                GlobalVariables::prog12F5xx,
                13.0,0,
                0x200,5, QList<int>(), 0x40, QList<int>()<<0x1FF,0);

     typePIC12F->addDevice("12F508", group3);
     typePIC10F->addDevice("10F202", group3);
     typePIC10F->addDevice("10F206", group3);
     typePIC10F->addDevice("10F222", group3);


     ReadWriteInfo  *group4=new ReadWriteInfo(
                 GlobalVariables::prog12F5xx,
                 GlobalVariables::prog12F5xx,
                 13.0,0,
                 0x200,4, QList<int>(), 0x40, QList<int>()<<-1,0);


     typePIC16F->addDevice("16F54",group4);

     ReadWriteInfo  *group5=new ReadWriteInfo(
                 GlobalVariables::prog12F5xx,
                 GlobalVariables::prog12C5xx,
                 13.0,0,
                 0x400,4, QList<int>(), 0x40, QList<int>()<<0,0);

     typePIC12F->addDevice("12C509", group5);
     typePIC12F->addDevice("12C509A", group5);

     ReadWriteInfo  *group6=new ReadWriteInfo(
                 GlobalVariables::prog12F5xx,
                 GlobalVariables::prog12F5xx,
                 13.0,0,
                 0x400,5, QList<int>(), 0x40, QList<int>()<<0x3FF,0);

     typePIC12F->addDevice("12F509", group6);
     typePIC12F->addDevice("12F510", group6);
     typePIC16F->addDevice("16F505",group6);
     typePIC16F->addDevice("16F506",group6);


     ReadWriteInfo  *group7=new ReadWriteInfo(
                 GlobalVariables::prog12F5xx,
                 GlobalVariables::prog12F5xx,
                 13.0,0,
                 0x440,8, QList<int>(), 0x60, QList<int>()<<0x3FF,0);
     typePIC12F->addDevice("12F519", group7);
     typePIC16F->addDevice("16F526",group7);
     typePIC16F->addDevice("16F527",group7);


     ReadWriteInfo  *group8=new ReadWriteInfo(
                 GlobalVariables::prog12F5xx,
                 GlobalVariables::prog12F5xx,
                 13.0,0,
                 0x800,4, QList<int>(), 0x40, QList<int>()<<-1,0); //2K

     /*

     typePIC16F->addDevice("16F57",group8);
     typePIC16F->addDevice("16F59",group8);

     ReadWriteInfo  *group9=new ReadWriteInfo(
                 GlobalVariables::prog16Fxxx,
                 GlobalVariables::prog16F8x,
                 13.0,0,
                 0x800,4, QList<int>(), 0x40, QList<int>()<<-1,0); //512, 64, vdd



    typePIC16F->addDevice("16F505", 0, 0);
    typePIC16F->addDevice("16F506", 0, 0);
    typePIC16F->addDevice("16F526", 0, 0);
    typePIC16F->addDevice("16F54", 0, 0);
    typePIC16F->addDevice("16F57", 0, 0);
    typePIC16F->addDevice("16F59", 0, 0);
    typePIC16F->addDevice("16F610", 0, 0);
    typePIC16F->addDevice("16F616", 0, 0);
    typePIC16F->addDevice("16F627", 0, 0);
    typePIC16F->addDevice("16F627A", 0, 0);
    typePIC16F->addDevice("16F628", 0, 0);
    typePIC16F->addDevice("16F628A", 0, 0);
    typePIC16F->addDevice("16F630", 0, 0);
    typePIC16F->addDevice("16F631", 0, 0);
    typePIC16F->addDevice("16F636", 0, 0);
    typePIC16F->addDevice("16F639", 0, 0);
    typePIC16F->addDevice("16F648A", 0, 0);
    typePIC16F->addDevice("16F676", 0, 0);
    typePIC16F->addDevice("16F677", 0, 0);
    typePIC16F->addDevice("16F684", 0, 0);
    typePIC16F->addDevice("16F685", 0, 0);
    typePIC16F->addDevice("16F687", 0, 0);
    typePIC16F->addDevice("16F688", 0, 0);
    typePIC16F->addDevice("16F689", 0, 0);
    typePIC16F->addDevice("16F690", 0, 0);
    typePIC16F->addDevice("16F707", 0, 0);
    typePIC16F->addDevice("16F716", 0, 0);
    typePIC16F->addDevice("16F72", 0, 0);
    typePIC16F->addDevice("16F720", 0, 0);
    typePIC16F->addDevice("16F721", 0, 0);
    typePIC16F->addDevice("16F722", 0, 0);
    typePIC16F->addDevice("16F722A", 0, 0);
    typePIC16F->addDevice("16F723", 0, 0);
    typePIC16F->addDevice("16F723A", 0, 0);
    typePIC16F->addDevice("16F724", 0, 0);
    typePIC16F->addDevice("16F726", 0, 0);
    typePIC16F->addDevice("16F727", 0, 0);
    typePIC16F->addDevice("16F73", 0, 0);
    typePIC16F->addDevice("16F737", 0, 0);
    typePIC16F->addDevice("16F74", 0, 0);
    typePIC16F->addDevice("16F747", 0, 0);
    typePIC16F->addDevice("16F76", 0, 0);
    typePIC16F->addDevice("16F767", 0, 0);
    typePIC16F->addDevice("16F77", 0, 0);
    typePIC16F->addDevice("16F777", 0, 0);
    typePIC16F->addDevice("16F785", 0, 0);
    typePIC16F->addDevice("16F818", 0, 0);
    typePIC16F->addDevice("16F819", 0, 0);
    typePIC16F->addDevice("16C83", 0, 0);
    typePIC16F->addDevice("16F83", 0, 0);
    typePIC16F->addDevice("16F83A", 0, 0);
    typePIC16F->addDevice("16C84", 0, 0);
    typePIC16F->addDevice("16F84", 0, 0);
    typePIC16F->addDevice("16F84A", 0, 0);
    typePIC16F->addDevice("16F87", 0, 0);
    typePIC16F->addDevice("16F870", 0, 0);
    typePIC16F->addDevice("16F871", 0, 0);
    typePIC16F->addDevice("16F872", 0, 0);
    typePIC16F->addDevice("16F873", 0, 0);
    typePIC16F->addDevice("16F873A", 0, 0);
    typePIC16F->addDevice("16F874", 0, 0);
    typePIC16F->addDevice("16F874A", 0, 0);
    typePIC16F->addDevice("16F876", 0, 0);
    typePIC16F->addDevice("16F876A", 0, 0);
    typePIC16F->addDevice("16F877", 0, 0);
    typePIC16F->addDevice("16F877A", 0, 0);
    typePIC16F->addDevice("16F88", 0, 0);
    typePIC16F->addDevice("16F882", 0, 0);
    typePIC16F->addDevice("16F883", 0, 0);
    typePIC16F->addDevice("16F884", 0, 0);
    typePIC16F->addDevice("16F886", 0, 0);
    typePIC16F->addDevice("16F887", 0, 0);
    typePIC16F->addDevice("16F913", 0, 0);
    typePIC16F->addDevice("16F914", 0, 0);
    typePIC16F->addDevice("16F916", 0, 0);
    typePIC16F->addDevice("16F917", 0, 0);
    typePIC16F->addDevice("16F946", 0, 0);
    typePIC16F->addDevice("16F1503", 0, 0);
    typePIC16F->addDevice("16F1507", 0, 0);
    typePIC16F->addDevice("16F1508", 0, 0);
    typePIC16F->addDevice("16F1509", 0, 0);
    typePIC16F->addDevice("16F1516", 0, 0);
    typePIC16F->addDevice("16F1517", 0, 0);
    typePIC16F->addDevice("16F1518", 0, 0);
    typePIC16F->addDevice("16F1519", 0, 0);
    typePIC16F->addDevice("16F1526", 0, 0);
    typePIC16F->addDevice("16F1527", 0, 0);
    typePIC16F->addDevice("16F1823", 0, 0);
    typePIC16F->addDevice("16F1824", 0, 0);
    typePIC16F->addDevice("16F1825", 0, 0);
    typePIC16F->addDevice("16F1826", 0, 0);
    typePIC16F->addDevice("16F1827", 0, 0);
    typePIC16F->addDevice("16F1828", 0, 0);
    typePIC16F->addDevice("16F1829", 0, 0);
    typePIC16F->addDevice("16F1847", 0, 0);
    typePIC16F->addDevice("16LF1902", 0, 0);
    typePIC16F->addDevice("16LF1903", 0, 0);
    typePIC16F->addDevice("16LF1904", 0, 0);
    typePIC16F->addDevice("16LF1906", 0, 0);
    typePIC16F->addDevice("16LF1907", 0, 0);
    typePIC16F->addDevice("16F1933", 0, 0);
    typePIC16F->addDevice("16F1934", 0, 0);
    typePIC16F->addDevice("16F1936", 0, 0);
    typePIC16F->addDevice("16F1937", 0, 0);
    typePIC16F->addDevice("16F1938", 0, 0);
    typePIC16F->addDevice("16F1939", 0, 0);
    typePIC16F->addDevice("16F1946", 0, 0);
    typePIC16F->addDevice("16F1947", 0, 0);


    typePIC18F->addDevice("18F242", 0, 0);
    typePIC18F->addDevice("18F248", 0, 0);
    typePIC18F->addDevice("18F252", 0, 0);
    typePIC18F->addDevice("18F258", 0, 0);
    typePIC18F->addDevice("18F442", 0, 0);
    typePIC18F->addDevice("18F448", 0, 0);
    typePIC18F->addDevice("18F452", 0, 0);
    typePIC18F->addDevice("18F458", 0, 0);
    typePIC18F->addDevice("18F1220", 0, 0);
    typePIC18F->addDevice("18F1230", 0, 0);
    typePIC18F->addDevice("18F1320", 0, 0);
    typePIC18F->addDevice("18F1330", 0, 0);
    typePIC18F->addDevice("18F13K22", 0, 0);
    typePIC18F->addDevice("18F13K50", 0, 0);
    typePIC18F->addDevice("18F14K22", 0, 0);
    typePIC18F->addDevice("18F14K50", 0, 0);
    typePIC18F->addDevice("18F2220", 0, 0);
    typePIC18F->addDevice("18F2221", 0, 0);
    typePIC18F->addDevice("18F2320", 0, 0);
    typePIC18F->addDevice("18F23K20", 0, 0);
    typePIC18F->addDevice("18F23K22", 0, 0);
    typePIC18F->addDevice("18F2321", 0, 0);
    typePIC18F->addDevice("18F2331", 0, 0);
    typePIC18F->addDevice("18F2410", 0, 0);
    typePIC18F->addDevice("18F24J10", 0, 0);
    typePIC18F->addDevice("18F24J11", 0, 0);
    typePIC18F->addDevice("18F2420", 0, 0);
    typePIC18F->addDevice("18F24K20", 0, 0);
    typePIC18F->addDevice("18F24K22", 0, 0);
    typePIC18F->addDevice("18F2423", 0, 0);
    typePIC18F->addDevice("18F2431", 0, 0);
    typePIC18F->addDevice("18F2439", 0, 0);
    typePIC18F->addDevice("18F2450", 0, 0);
    typePIC18F->addDevice("18F24J50", 0, 0);
    typePIC18F->addDevice("18F2455", 0, 0);
    typePIC18F->addDevice("18F2458", 0, 0);
    typePIC18F->addDevice("18F2480", 0, 0);
    typePIC18F->addDevice("18F2510", 0, 0);
    typePIC18F->addDevice("18F25J10", 0, 0);
    typePIC18F->addDevice("18F25J11", 0, 0);
    typePIC18F->addDevice("18F2515", 0, 0);
    typePIC18F->addDevice("18F25K20", 0, 0);
    typePIC18F->addDevice("18F25K22", 0, 0);
    typePIC18F->addDevice("18F2520", 0, 0);
    typePIC18F->addDevice("18F2523", 0, 0);
    typePIC18F->addDevice("18F2525", 0, 0);
    typePIC18F->addDevice("18F2539", 0, 0);
    typePIC18F->addDevice("18F2550", 0, 0);
    typePIC18F->addDevice("18F25J50", 0, 0);
    typePIC18F->addDevice("18F2553", 0, 0);
    typePIC18F->addDevice("18F2580", 0, 0);
    typePIC18F->addDevice("18F2585", 0, 0);
    typePIC18F->addDevice("18F2610", 0, 0);
    typePIC18F->addDevice("18F26J11", 0, 0);
    typePIC18F->addDevice("18F26J13", 0, 0);
    typePIC18F->addDevice("18F2620", 0, 0);
    typePIC18F->addDevice("18F26K20", 0, 0);
    typePIC18F->addDevice("18F26K22", 0, 0);
    typePIC18F->addDevice("18F26J50", 0, 0);
    typePIC18F->addDevice("18F26J53", 0, 0);
    typePIC18F->addDevice("18F2680", 0, 0);
    typePIC18F->addDevice("18F2682", 0, 0);
    typePIC18F->addDevice("18F2685", 0, 0);
    typePIC18F->addDevice("18F27J13", 0, 0);
    typePIC18F->addDevice("18F27J53", 0, 0);
    typePIC18F->addDevice("18F4220", 0, 0);
    typePIC18F->addDevice("18F4221", 0, 0);
    typePIC18F->addDevice("18F4320", 0, 0);
    typePIC18F->addDevice("18F43K20", 0, 0);
    typePIC18F->addDevice("18F43K22", 0, 0);
    typePIC18F->addDevice("18F4321", 0, 0);
    typePIC18F->addDevice("18F4331", 0, 0);
    typePIC18F->addDevice("18F4410", 0, 0);
    typePIC18F->addDevice("18F44J10", 0, 0);
    typePIC18F->addDevice("18F44J11", 0, 0);
    typePIC18F->addDevice("18F4420", 0, 0);
    typePIC18F->addDevice("18F44K20", 0, 0);
    typePIC18F->addDevice("18F44K22", 0, 0);
    typePIC18F->addDevice("18F4423", 0, 0);
    typePIC18F->addDevice("18F4431", 0, 0);
    typePIC18F->addDevice("18F4439", 0, 0);
    typePIC18F->addDevice("18F4450", 0, 0);
    typePIC18F->addDevice("18F44J50", 0, 0);
    typePIC18F->addDevice("18F4455", 0, 0);
    typePIC18F->addDevice("18F4458", 0, 0);
    typePIC18F->addDevice("18F4480", 0, 0);
    typePIC18F->addDevice("18F4510", 0, 0);
    typePIC18F->addDevice("18F45J10", 0, 0);
    typePIC18F->addDevice("18F45J11", 0, 0);
    typePIC18F->addDevice("18F4515", 0, 0);
    typePIC18F->addDevice("18F4520", 0, 0);
    typePIC18F->addDevice("18F45K20", 0, 0);
    typePIC18F->addDevice("18F45K22", 0, 0);
    typePIC18F->addDevice("18F4523", 0, 0);
    typePIC18F->addDevice("18F4525", 0, 0);
    typePIC18F->addDevice("18F4539", 0, 0);
    typePIC18F->addDevice("18F4550", 0, 0);
    typePIC18F->addDevice("18F45J50", 0, 0);
    typePIC18F->addDevice("18F4553", 0, 0);
    typePIC18F->addDevice("18F4580", 0, 0);
    typePIC18F->addDevice("18F4585", 0, 0);
    typePIC18F->addDevice("18F4610", 0, 0);
    typePIC18F->addDevice("18F46J11", 0, 0);
    typePIC18F->addDevice("18F46J13", 0, 0);
    typePIC18F->addDevice("18F4620", 0, 0);
    typePIC18F->addDevice("18F46K20", 0, 0);
    typePIC18F->addDevice("18F46K22", 0, 0);
    typePIC18F->addDevice("18F46J50", 0, 0);
    typePIC18F->addDevice("18F46J53", 0, 0);
    typePIC18F->addDevice("18F4680", 0, 0);
    typePIC18F->addDevice("18F4682", 0, 0);
    typePIC18F->addDevice("18F4685", 0, 0);
    typePIC18F->addDevice("18F47J13", 0, 0);
    typePIC18F->addDevice("18F47J53", 0, 0);
    typePIC18F->addDevice("18F66J60", 0, 0);
    typePIC18F->addDevice("18F66J65", 0, 0);
    typePIC18F->addDevice("18F67J60", 0, 0);
    typePIC18F->addDevice("18F8520", 0, 0);
    typePIC18F->addDevice("18F86J60", 0, 0);
    typePIC18F->addDevice("18F86J65", 0, 0);
    typePIC18F->addDevice("18F87J60", 0, 0);
    typePIC18F->addDevice("18F8722", 0, 0);
    typePIC18F->addDevice("18F96J60", 0, 0);
    typePIC18F->addDevice("18F96J65", 0, 0);
    typePIC18F->addDevice("18F97J60", 0, 0);


    typePIC24CF->addDevice("24CF04KA200", 0, 0);
    typePIC24CF->addDevice("24CF04KA201", 0, 0);
    typePIC24CF->addDevice("24CF08KA101", 0, 0);
    typePIC24CF->addDevice("24CF08KA102", 0, 0);
    typePIC24CF->addDevice("24CF16KA101", 0, 0);
    typePIC24CF->addDevice("24CF16KA102", 0, 0);
    typePIC24CF->addDevice("24CFJ16GA002", 0, 0);
    typePIC24CF->addDevice("24CFJ16GA004", 0, 0);
    typePIC24CF->addDevice("24CFJ32GA002", 0, 0);
    typePIC24CF->addDevice("24CFJ32GA004", 0, 0);
    typePIC24CF->addDevice("24CFJ32GA102", 0, 0);
    typePIC24CF->addDevice("24CFJ32GA104", 0, 0);
    typePIC24CF->addDevice("24CFJ32GB002", 0, 0);
    typePIC24CF->addDevice("24CFJ32GB004", 0, 0);
    typePIC24CF->addDevice("24CFJ48GA002", 0, 0);
    typePIC24CF->addDevice("24CFJ48GA004", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA002", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA004", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA006", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA008", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA010", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA102", 0, 0);
    typePIC24CF->addDevice("24CFJ64GA104", 0, 0);
    typePIC24CF->addDevice("24FJ64GA306", 0, 0);
    typePIC24CF->addDevice("24FJ64GA308", 0, 0);
    typePIC24CF->addDevice("24FJ64GA310", 0, 0);
    typePIC24CF->addDevice("24CFJ64GB002", 0, 0);
    typePIC24CF->addDevice("24CFJ64GB004", 0, 0);
    typePIC24CF->addDevice("24CFJ64GB106", 0, 0);
    typePIC24CF->addDevice("24CFJ64GB108", 0, 0);
    typePIC24CF->addDevice("24CFJ64GB110", 0, 0);
    typePIC24CF->addDevice("24CFJ96GA006", 0, 0);
    typePIC24CF->addDevice("24CFJ96GA008", 0, 0);
    typePIC24CF->addDevice("24CFJ96GA010", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA006", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA008", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA010", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA106", 0, 0);
    typePIC24CF->addDevice("24CFJ128GB106", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA108", 0, 0);
    typePIC24CF->addDevice("24CFJ128GB108", 0, 0);
    typePIC24CF->addDevice("24CFJ128GA110", 0, 0);
    typePIC24CF->addDevice("24FJ128GA306", 0, 0);
    typePIC24CF->addDevice("24FJ128GA308", 0, 0);
    typePIC24CF->addDevice("24FJ128GA310", 0, 0);

    typePIC24CF->addDevice("24CFJ128GB110", 0, 0);
    typePIC24CH->addDevice("24FJ128GB206", 0, 0);
    typePIC24CH->addDevice("24FJ128GB210", 0, 0);
    typePIC24CH->addDevice("24FJ128GC006", 0, 0);
    typePIC24CH->addDevice("24FJ128GC008", 0, 0);
    typePIC24CH->addDevice("224FJ128GC010", 0, 0);
    typePIC24CH->addDevice("24FJ128DA106", 0, 0);
    typePIC24CH->addDevice("24FJ128DA110", 0, 0);
    typePIC24CH->addDevice("24FJ128DA206", 0, 0);
    typePIC24CH->addDevice("24FJ128DA210", 0, 0);


    typePIC24CF->addDevice("24CFJ192GA106", 0, 0);
    typePIC24CF->addDevice("24CFJ192GB106", 0, 0);
    typePIC24CF->addDevice("24CFJ192GA108", 0, 0);
    typePIC24CF->addDevice("24CFJ192GB108", 0, 0);
    typePIC24CF->addDevice("24CFJ192GA110", 0, 0);
    typePIC24CF->addDevice("24CFJ192GB110", 0, 0);
    typePIC24CF->addDevice("24CFJ256GA106", 0, 0);
    typePIC24CF->addDevice("24CFJ256GB106", 0, 0);
    typePIC24CF->addDevice("24CFJ256GA108", 0, 0);
    typePIC24CF->addDevice("24CFJ256GB108", 0, 0);
    typePIC24CF->addDevice("24CFJ256GA110", 0, 0);
    typePIC24CF->addDevice("24CFJ256GB110", 0, 0);


    typePIC24CH->addDevice("24FJ256DA106", 0, 0);
    typePIC24CH->addDevice("24FJ256DA110", 0, 0);
    typePIC24CH->addDevice("24FJ256DA206", 0, 0);
    typePIC24CH->addDevice("24FJ256DA210", 0, 0);


    typePIC24CH->addDevice("24CHJ12GP201", 0, 0);
    typePIC24CH->addDevice("24CHJ12GP202", 0, 0);
    typePIC24CH->addDevice("24CHJ16GP304", 0, 0);
    typePIC24CH->addDevice("24CHJ32GP202", 0, 0);
    typePIC24CH->addDevice("24CHJ32GP204", 0, 0);
    typePIC24CH->addDevice("24CHJ32GP302", 0, 0);
    typePIC24CH->addDevice("24CHJ32GP304", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP202", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP204", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP206", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP210", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP502", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP504", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP506", 0, 0);
    typePIC24CH->addDevice("24CHJ64GP510", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP202", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP204", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP206", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP210", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP306", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP310", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP502", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP504", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP506", 0, 0);
    typePIC24CH->addDevice("24CHJ128GP510", 0, 0);
    typePIC24CH->addDevice("24CHJ256GP206", 0, 0);
    typePIC24CH->addDevice("24CHJ256GP210", 0, 0);
    typePIC24CH->addDevice("24CHJ256GP610", 0, 0);


    typePIC24EP->addDevice("24EP32GP202", 0, 0);
    typePIC24EP->addDevice("24EP32GP203", 0, 0);
    typePIC24EP->addDevice("24EP32GP204", 0, 0);
    typePIC24EP->addDevice("24EP32MC202", 0, 0);
    typePIC24EP->addDevice("24EP32MC203", 0, 0);
    typePIC24EP->addDevice("24EP32MC204", 0, 0);
    typePIC24EP->addDevice("24EP64GP202", 0, 0);
    typePIC24EP->addDevice("24EP64GP203", 0, 0);
    typePIC24EP->addDevice("24EP64GP204", 0, 0);
    typePIC24EP->addDevice("24EP64GP206", 0, 0);
    typePIC24EP->addDevice("24EP64MC202", 0, 0);
    typePIC24EP->addDevice("24EP64MC203", 0, 0);
    typePIC24EP->addDevice("24EP64MC204", 0, 0);
    typePIC24EP->addDevice("24EP64MC206", 0, 0);
    typePIC24EP->addDevice("24EP128GP202", 0, 0);
    typePIC24EP->addDevice("24EP128GP204", 0, 0);
    typePIC24EP->addDevice("24EP128GP206", 0, 0);
    typePIC24EP->addDevice("24EP128MC202", 0, 0);
    typePIC24EP->addDevice("24EP128MC204", 0, 0);
    typePIC24EP->addDevice("24EP128MC206", 0, 0);
    typePIC24EP->addDevice("24EP256GP202", 0, 0);
    typePIC24EP->addDevice("24EP256GP204", 0, 0);
    typePIC24EP->addDevice("24EP256GP206", 0, 0);
    typePIC24EP->addDevice("24EP256MC202", 0, 0);
    typePIC24EP->addDevice("24EP256MC204", 0, 0);
    typePIC24EP->addDevice("24EP256MC206", 0, 0);
    typePIC24EP->addDevice("24EP512GP202", 0, 0);
    typePIC24EP->addDevice("24EP512GP204", 0, 0);
    typePIC24EP->addDevice("24EP512GP206", 0, 0);
    typePIC24EP->addDevice("24EP512MC202", 0, 0);
    typePIC24EP->addDevice("24EP512MC204", 0, 0);
    typePIC24EP->addDevice("24EP512MC206", 0, 0);




    typePIC30F->addDevice("30F1010", 0, 0);
    typePIC30F->addDevice("30F2010", 0, 0);
    typePIC30F->addDevice("30F2011", 0, 0);
    typePIC30F->addDevice("30F2012", 0, 0);
    typePIC30F->addDevice("30F2020", 0, 0);
    typePIC30F->addDevice("30F2023", 0, 0);
    typePIC30F->addDevice("30F3010", 0, 0);
    typePIC30F->addDevice("30F3011", 0, 0);
    typePIC30F->addDevice("30F3012", 0, 0);
    typePIC30F->addDevice("30F3013", 0, 0);
    typePIC30F->addDevice("30F3014", 0, 0);
    typePIC30F->addDevice("30F4011", 0, 0);
    typePIC30F->addDevice("30F4012", 0, 0);
    typePIC30F->addDevice("30F4013", 0, 0);
    typePIC30F->addDevice("30F5011", 0, 0);
    typePIC30F->addDevice("30F5013", 0, 0);
    typePIC30F->addDevice("30F5015", 0, 0);
    typePIC30F->addDevice("30F5016", 0, 0);
    typePIC30F->addDevice("30F6010", 0, 0);
    typePIC30F->addDevice("30F6011", 0, 0);
    typePIC30F->addDevice("30F6012", 0, 0);
    typePIC30F->addDevice("30F6013", 0, 0);
    typePIC30F->addDevice("30F6014", 0, 0);
    typePIC30F->addDevice("30F6015", 0, 0);

    typePIC33F->addDevice("33FJ06GS101", 0, 0);
    typePIC33F->addDevice("33FJ06GS102", 0, 0);
    typePIC33F->addDevice("33FJ06GS202", 0, 0);
    typePIC33F->addDevice("33FJ12GP201", 0, 0);
    typePIC33F->addDevice("33FJ12GP202", 0, 0);
    typePIC33F->addDevice("33FJ12MC201", 0, 0);
    typePIC33F->addDevice("33FJ12MC202", 0, 0);
    typePIC33F->addDevice("33FJ16GP304", 0, 0);
    typePIC33F->addDevice("33FJ16GS402", 0, 0);
    typePIC33F->addDevice("33FJ16GS404", 0, 0);
    typePIC33F->addDevice("33FJ16GS502", 0, 0);
    typePIC33F->addDevice("33FJ16GS504", 0, 0);
    typePIC33F->addDevice("33FJ16MC304", 0, 0);
    typePIC33F->addDevice("33FJ32GP202", 0, 0);
    typePIC33F->addDevice("33FJ32GP204", 0, 0);
    typePIC33F->addDevice("33FJ32GP302", 0, 0);
    typePIC33F->addDevice("33FJ32GP304", 0, 0);
    typePIC33F->addDevice("33FJ32GS406", 0, 0);
    typePIC33F->addDevice("33FJ32GS606", 0, 0);
    typePIC33F->addDevice("33FJ32GS608", 0, 0);
    typePIC33F->addDevice("33FJ32GS610", 0, 0);
    typePIC33F->addDevice("33FJ32MC202", 0, 0);
    typePIC33F->addDevice("33FJ32MC204", 0, 0);
    typePIC33F->addDevice("33FJ32MC302", 0, 0);
    typePIC33F->addDevice("33FJ32MC304", 0, 0);
    typePIC33F->addDevice("33FJ64GP202", 0, 0);
    typePIC33F->addDevice("33FJ64GP204", 0, 0);
    typePIC33F->addDevice("33FJ64GP206", 0, 0);
    typePIC33F->addDevice("33FJ64GP306", 0, 0);
    typePIC33F->addDevice("33FJ64GP310", 0, 0);
    typePIC33F->addDevice("33FJ64GP706", 0, 0);
    typePIC33F->addDevice("33FJ64GP708", 0, 0);
    typePIC33F->addDevice("33FJ64GP710", 0, 0);
    typePIC33F->addDevice("33FJ64GP802", 0, 0);
    typePIC33F->addDevice("33FJ64GP804", 0, 0);
    typePIC33F->addDevice("33FJ64GS406", 0, 0);
    typePIC33F->addDevice("33FJ64GS606", 0, 0);
    typePIC33F->addDevice("33FJ64GS608", 0, 0);
    typePIC33F->addDevice("33FJ64GS610", 0, 0);
    typePIC33F->addDevice("33FJ64MC202", 0, 0);
    typePIC33F->addDevice("33FJ64MC204", 0, 0);
    typePIC33F->addDevice("33FJ64MC506", 0, 0);
    typePIC33F->addDevice("33FJ64MC508", 0, 0);
    typePIC33F->addDevice("33FJ64MC510", 0, 0);
    typePIC33F->addDevice("33FJ64MC706", 0, 0);
    typePIC33F->addDevice("33FJ64MC710", 0, 0);
    typePIC33F->addDevice("33FJ64MC802", 0, 0);
    typePIC33F->addDevice("33FJ64MC804", 0, 0);
    typePIC33F->addDevice("33FJ128GP202", 0, 0);
    typePIC33F->addDevice("33FJ128GP204", 0, 0);
    typePIC33F->addDevice("33FJ128GP206", 0, 0);
    typePIC33F->addDevice("33FJ128GP306", 0, 0);
    typePIC33F->addDevice("33FJ128GP310", 0, 0);
    typePIC33F->addDevice("33FJ128GP706", 0, 0);
    typePIC33F->addDevice("33FJ128GP708", 0, 0);
    typePIC33F->addDevice("33FJ128GP710", 0, 0);
    typePIC33F->addDevice("33FJ128GP802", 0, 0);
    typePIC33F->addDevice("33FJ128GP804", 0, 0);
    typePIC33F->addDevice("33FJ128MC202", 0, 0);
    typePIC33F->addDevice("33FJ128MC204", 0, 0);
    typePIC33F->addDevice("33FJ128MC506", 0, 0);
    typePIC33F->addDevice("33FJ128MC510", 0, 0);
    typePIC33F->addDevice("33FJ128MC706", 0, 0);
    typePIC33F->addDevice("33FJ128MC708", 0, 0);
    typePIC33F->addDevice("33FJ128MC710", 0, 0);
    typePIC33F->addDevice("33FJ128MC802", 0, 0);
    typePIC33F->addDevice("33FJ128MC804", 0, 0);
    typePIC33F->addDevice("33FJ256GP506", 0, 0);
    typePIC33F->addDevice("33FJ256GP510", 0, 0);
    typePIC33F->addDevice("33FJ256GP710", 0, 0);
    typePIC33F->addDevice("33FJ256MC510", 0, 0);
    typePIC33F->addDevice("33FJ256MC710", 0, 0);

    typePIC33EP->addDevice("33EP32GP502", 0, 0);
    typePIC33EP->addDevice("33EP32GP503", 0, 0);
    typePIC33EP->addDevice("33EP32GP504", 0, 0);
    typePIC33EP->addDevice("33EP32MC202", 0, 0);
    typePIC33EP->addDevice("33EP32MC203", 0, 0);
    typePIC33EP->addDevice("33EP32MC204", 0, 0);
    typePIC33EP->addDevice("33EP32MC502", 0, 0);
    typePIC33EP->addDevice("33EP32MC503", 0, 0);
    typePIC33EP->addDevice("33EP32MC504", 0, 0);
    typePIC33EP->addDevice("33EP64GP502", 0, 0);
    typePIC33EP->addDevice("33EP64GP503", 0, 0);
    typePIC33EP->addDevice("33EP64GP504", 0, 0);
    typePIC33EP->addDevice("33EP64GP506", 0, 0);
    typePIC33EP->addDevice("33EP64MC202", 0, 0);
    typePIC33EP->addDevice("33EP64MC203", 0, 0);
    typePIC33EP->addDevice("33EP64MC204", 0, 0);
    typePIC33EP->addDevice("33EP64MC206", 0, 0);
    typePIC33EP->addDevice("33EP64MC502", 0, 0);
    typePIC33EP->addDevice("33EP64MC503", 0, 0);
    typePIC33EP->addDevice("33EP64MC504", 0, 0);
    typePIC33EP->addDevice("33EP64MC506", 0, 0);
    typePIC33EP->addDevice("33EP128GP502", 0, 0);
    typePIC33EP->addDevice("33EP128GP504", 0, 0);
    typePIC33EP->addDevice("33EP128GP506", 0, 0);
    typePIC33EP->addDevice("33EP128MC202", 0, 0);
    typePIC33EP->addDevice("33EP128MC204", 0, 0);
    typePIC33EP->addDevice("33EP128MC206", 0, 0);
    typePIC33EP->addDevice("33EP128MC502", 0, 0);
    typePIC33EP->addDevice("33EP128MC504", 0, 0);
    typePIC33EP->addDevice("33EP128MC506", 0, 0);
    typePIC33EP->addDevice("33EP256GP502", 0, 0);
    typePIC33EP->addDevice("33EP256GP504", 0, 0);
    typePIC33EP->addDevice("33EP256GP506", 0, 0);
    typePIC33EP->addDevice("33EP256MC202", 0, 0);
    typePIC33EP->addDevice("33EP256MC204", 0, 0);
    typePIC33EP->addDevice("33EP256MC206", 0, 0);
    typePIC33EP->addDevice("33EP256MC502", 0, 0);
    typePIC33EP->addDevice("33EP256MC504", 0, 0);
    typePIC33EP->addDevice("33EP256MC506", 0, 0);
    typePIC33EP->addDevice("33EP512GP502", 0, 0);
    typePIC33EP->addDevice("33EP512GP504", 0, 0);
    typePIC33EP->addDevice("33EP512GP506", 0, 0);
    typePIC33EP->addDevice("33EP512MC202", 0, 0);
    typePIC33EP->addDevice("33EP512MC204", 0, 0);
    typePIC33EP->addDevice("33EP512MC206", 0, 0);
    typePIC33EP->addDevice("33EP512MC502", 0, 0);
    typePIC33EP->addDevice("33EP512MC504", 0, 0);
    typePIC33EP->addDevice("33EP512MC506", 0, 0);

    typeAVRAT90->addDevice("AT90S1200", 0, 0);
    typeAVRAT90->addDevice("AT90S2313", 0, 0);
    typeAVRAT90->addDevice("AT90S8515", 0, 0);
    typeAVRAT90->addDevice("AT90S8535", 0, 0);

    typeAVRATmega->addDevice("ATmega48", 0, 0);
    typeAVRATmega->addDevice("ATmega8", 0, 0);
    typeAVRATmega->addDevice("ATmega88", 0, 0);
    typeAVRATmega->addDevice("ATmega8515", 0, 0);
    typeAVRATmega->addDevice("ATmega8535", 0, 0);
    typeAVRATmega->addDevice("ATmega16", 0, 0);
    typeAVRATmega->addDevice("ATmega164A", 0, 0);
    typeAVRATmega->addDevice("ATmega168", 0, 0);
    typeAVRATmega->addDevice("ATmega32", 0, 0);
    typeAVRATmega->addDevice("ATmega324CA", 0, 0);
    typeAVRATmega->addDevice("ATmega328", 0, 0);
    typeAVRATmega->addDevice("ATmega64", 0, 0);
    typeAVRATmega->addDevice("ATmega644A", 0, 0);
    typeAVRATmega->addDevice("ATmega1284", 0, 0);

    typeAVRATtiny->addDevice("ATtiny11", 0, 0);
    typeAVRATtiny->addDevice("ATtiny12", 0, 0);
    typeAVRATtiny->addDevice("ATtiny13", 0, 0);
    typeAVRATtiny->addDevice("ATtiny24", 0, 0);
    typeAVRATtiny->addDevice("ATtiny25", 0, 0);
    typeAVRATtiny->addDevice("ATtiny26", 0, 0);
    typeAVRATtiny->addDevice("ATtiny261", 0, 0);
    typeAVRATtiny->addDevice("ATtiny2313", 0, 0);
    typeAVRATtiny->addDevice("ATtiny4313", 0, 0);
    typeAVRATtiny->addDevice("ATtiny44", 0, 0);
    typeAVRATtiny->addDevice("ATtiny45", 0, 0);
    typeAVRATtiny->addDevice("ATtiny461", 0, 0);
    typeAVRATtiny->addDevice("ATtiny48", 0, 0);
    typeAVRATtiny->addDevice("ATtiny84", 0, 0);
    typeAVRATtiny->addDevice("ATtiny85", 0, 0);
    typeAVRATtiny->addDevice("ATtiny88", 0, 0);
    typeAVRATtiny->addDevice("ATtiny861", 0, 0);

    typeI2C24C->addDevice("24C00", 0, 0);
    typeI2C24C->addDevice("24C01", 0, 0);
    typeI2C24C->addDevice("24C02", 0, 0);
    typeI2C24C->addDevice("24C04", 0, 0);
    typeI2C24C->addDevice("24C08", 0, 0);
    typeI2C24C->addDevice("24C16", 0, 0);
    typeI2C24C->addDevice("24C32", 0, 0);
    typeI2C24C->addDevice("24C64", 0, 0);
    typeI2C24C->addDevice("24C128", 0, 0);
    typeI2C24C->addDevice("24C256", 0, 0);
    typeI2C24C->addDevice("24C512", 0, 0);
    typeI2C24C->addDevice("24C1024", 0, 0);
    typeI2C24C->addDevice("24C1025", 0, 0);


    typeSPI95->addDevice("95010", 0, 0);
    typeSPI95->addDevice("95020", 0, 0);
    typeSPI95->addDevice("95040", 0, 0);
    typeSPI95->addDevice("95080", 0, 0);
    typeSPI95->addDevice("95160", 0, 0);
    typeSPI95->addDevice("95320", 0, 0);
    typeSPI95->addDevice("95640", 0, 0);
    typeSPI95->addDevice("95128", 0, 0);
    typeSPI95->addDevice("95256", 0, 0);
    typeSPI95->addDevice("95512", 0, 0);
    typeSPI95->addDevice("95M01", 0, 0);
    typeSPI95->addDevice("95M02", 0, 0);

    typeFlash25->addDevice("25010", 0, 0);
    typeFlash25->addDevice("25020", 0, 0);
    typeFlash25->addDevice("25040", 0, 0);
    typeFlash25->addDevice("25080", 0, 0);
    typeFlash25->addDevice("25160", 0, 0);
    typeFlash25->addDevice("25320", 0, 0);
    typeFlash25->addDevice("25640", 0, 0);
    typeFlash25->addDevice("25128", 0, 0);
    typeFlash25->addDevice("25256", 0, 0);
    typeFlash25->addDevice("25512", 0, 0);
    typeFlash25->addDevice("251024", 0, 0);
    typeFlash25->addDevice("251005", 0, 0);
    typeFlash25->addDevice("252005", 0, 0);
    typeFlash25->addDevice("254005", 0, 0);
    typeFlash25->addDevice("258005", 0, 0);
    typeFlash25->addDevice("251605", 0, 0);


    typeFlash25->addDevice("25X10", 0, 0);
    typeFlash25->addDevice("25X20", 0, 0);
    typeFlash25->addDevice("25X40", 0, 0);
    typeFlash25->addDevice("25X80", 0, 0);
    typeFlash25->addDevice("25X16", 0, 0);
    typeFlash25->addDevice("25X32", 0, 0);
    typeFlash25->addDevice("25X64", 0, 0);

    typeSPI93->addDevice("93S46", 0, 0);
    typeSPI93->addDevice("93x46", 0, 0);
    typeSPI93->addDevice("93x46A", 0, 0);
    typeSPI93->addDevice("93S56", 0, 0);
    typeSPI93->addDevice("93x56", 0, 0);
    typeSPI93->addDevice("93x56A", 0, 0);
    typeSPI93->addDevice("93S66", 0, 0);
    typeSPI93->addDevice("93x66", 0, 0);
    typeSPI93->addDevice("93x66A", 0, 0);
    typeSPI93->addDevice("93x76", 0, 0);
    typeSPI93->addDevice("93x76A", 0, 0);
    typeSPI93->addDevice("93x86", 0, 0);
    typeSPI93->addDevice("93x86A", 0, 0);

    typeOneWireDS->addDevice("DS24C30", 0, 0);
    typeOneWireDS->addDevice("DS24C31", 0, 0);
    typeOneWireDS->addDevice("DS24C33", 0, 0);
    typeOneWireDS->addDevice("DS28EC20", 0, 0);
    typeOneWireDS->addDevice("DS1820", 0, 0);

    typeOneWire11->addDevice("11010", 0, 0);
    typeOneWire11->addDevice("11020", 0, 0);
    typeOneWire11->addDevice("11040", 0, 0);
    typeOneWire11->addDevice("11080", 0, 0);
    typeOneWire11->addDevice("11160", 0, 0);
    */
}


