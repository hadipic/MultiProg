#ifndef PROGDEVICE_H
#define PROGDEVICE_H

#include <QObject>
#include <HardwareLayer/usbTools.h>
#include <QDebug>

class ProgDevice : public QObject
{
    Q_OBJECT
public:
    explicit ProgDevice(USBTools *usb, QObject *parent = 0);
    virtual void read(int a, int b, int c, int d);
    virtual void write(int a=0, int b=0, int c=0, int d=0, int e=0, int f=0);
protected:
    USBTools *usb;
signals:
    
public slots:
    
};

#endif // PROGDEVICE_H
