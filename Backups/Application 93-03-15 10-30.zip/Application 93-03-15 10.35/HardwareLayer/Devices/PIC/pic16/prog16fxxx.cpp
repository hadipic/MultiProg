#include "prog16fxxx.h"
Prog16Fxxx::Prog16Fxxx(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{
}

void Prog16Fxxx::read(int dim, int dim2, int c, int d)
{
}

void Prog16Fxxx::write(int dim, int dummy, int c, int d, int e, int f)
{
}
