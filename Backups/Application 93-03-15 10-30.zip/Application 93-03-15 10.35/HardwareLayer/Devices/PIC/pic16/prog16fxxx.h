#ifndef PROG16FXXX_H
#define PROG16FXXX_H

#include "HardwareLayer/Devices/progDevice.h"

class Prog16Fxxx : public ProgDevice
{
    Q_OBJECT
public:

public:
    Prog16Fxxx(USBTools *usb, QObject *parent = 0);
    virtual void read(int dim, int dim2, int c=0, int d=0);
    virtual void write(int dim,int dummy, int c=0, int d=0, int e=0, int f=0);


    
signals:
    
public slots:
    
};

#endif // PROG16FXXX_H
