QT += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = OpenProgrammer
TEMPLATE = app

HEADERS       = \
    mainwindow.h \
    HardwareLayer/usbTools.h \
    HardwareLayer/instructions.h \
    HardwareLayer/Devices/Memory/progEEPROM.h \
    Libs/commonFunctions.h \
    widgets/hexEditor/hexPlainTextEdit.h \
    widgets/hexEditor/hexEditor.h \
    widgets/hexEditor/asciiPlainTextEdit.h \
    widgets/fuzeSettings.h \
    HardwareLayer/Devices/devices.h \
    widgets/deviceListWidget.h \
    HardwareLayer/Devices/progAVR.h \
    HardwareLayer/Devices/progDevice.h \
    Libs/globalVariables.h \
    HardwareLayer/Devices/PIC/Pic12/prog12f5xx.h \
    HardwareLayer/Devices/PIC/Pic12/prog12c5xx.h \
    HardwareLayer/Devices/PIC/pic16/prog16fxxx.h \
    HardwareLayer/Devices/PIC/progP12.h
SOURCES       = main.cpp \
    mainwindow.cpp \
    HardwareLayer/usbTools.cpp \
    HardwareLayer/Devices/Memory/progEEPROM.cpp \
    Libs/commonFunctions.cpp \
    widgets/hexEditor/hexPlainTextEdit.cpp \
    widgets/hexEditor/hexEditor.cpp \
    widgets/hexEditor/asciiPlainTextEdit.cpp \
    widgets/fuzeSettings.cpp \
    HardwareLayer/Devices/devices.cpp \
    widgets/deviceListWidget.cpp \
    HardwareLayer/Devices/progAVR.cpp \
    HardwareLayer/Devices/progDevice.cpp \
    Libs/globalVariables.cpp \
    HardwareLayer/Devices/PIC/Pic12/prog12f5xx.cpp \
    HardwareLayer/Devices/PIC/Pic12/prog12c5xx.cpp \
    HardwareLayer/Devices/PIC/pic16/prog16fxxx.cpp \
    HardwareLayer/Devices/PIC/progP12.cpp
#! [0]
RESOURCES     = AllProgrammer.qrc
#! [0]


FORMS += \
    mainwindow.ui \
    widgets/hexEditor/hexEditor.ui \
    widgets/fuzeSettings.ui \
    widgets/deviceListWidget.ui
LIBS += -lsetupapi -ladvapi32 -lws2_32

