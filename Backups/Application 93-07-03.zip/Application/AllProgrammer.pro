QT += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets xml

TARGET = AllProgrammer
TEMPLATE = app

HEADERS       = \
    mainwindow.h \
    HardwareLayer/usbTools.h \
    HardwareLayer/instructions.h \
    HardwareLayer/Devices/Memory/progEEPROM.h \
    Libs/commonFunctions.h \
    widgets/hexEditor/hexPlainTextEdit.h \
    widgets/hexEditor/hexEditor.h \
    widgets/hexEditor/asciiPlainTextEdit.h \
    widgets/fuseSettings/fuseSettings.h \
    HardwareLayer/Devices/devices.h \
    widgets/deviceListWidget.h \
    HardwareLayer/Devices/progDevice.h \
    Libs/globalVariables.h \
    HardwareLayer/Devices/PIC/progP12.h \
    HardwareLayer/Devices/PIC/progP16.h \
    HardwareLayer/Devices/PIC/progP18.h \
    HardwareLayer/Devices/PIC/progP24.h \
    HardwareLayer/Devices/AVR/progAVR.h \
    HardwareLayer/Devices/readWriteInfo.h \
    Libs/strings.h \
    Forms/ioCheck.h \
    Forms/convert.h \
    Forms/icd.h \
    Forms/dis_asmble.h \
    HardwareLayer/Protcol/icd_protcol.h \
    HardwareLayer/Protcol/i2c_spi_protcol.h \
    HardwareLayer/fileIO.h \
    widgets/scrollTest.h \
    HardwareLayer/Devices/AVR/readXMLAVRList.h \
    HardwareLayer/Devices/AVR/avrFuse.h \
    widgets/fuseSettings/avrFuseSettings.h \
    widgets/fuseSettings/picFuseSettings.h \
    HardwareLayer/Devices/fuseStruct.h \
    HardwareLayer/Devices/PIC/readXMLPIC.h \
    Libs/xmlFunctions.h
SOURCES       = main.cpp \
    mainwindow.cpp \
    HardwareLayer/usbTools.cpp \
    HardwareLayer/Devices/Memory/progEEPROM.cpp \
    Libs/commonFunctions.cpp \
    widgets/hexEditor/hexPlainTextEdit.cpp \
    widgets/hexEditor/hexEditor.cpp \
    widgets/hexEditor/asciiPlainTextEdit.cpp \
    widgets/fuseSettings/fuseSettings.cpp \
    widgets/fuseSettings/avrFuseSettings.cpp \
    HardwareLayer/Devices/devices.cpp \
    widgets/deviceListWidget.cpp \
    HardwareLayer/Devices/progDevice.cpp \
    Libs/globalVariables.cpp \
    HardwareLayer/Devices/PIC/progP12.cpp \
    HardwareLayer/Devices/PIC/progP16.cpp \
    HardwareLayer/Devices/PIC/progP18.cpp \
    HardwareLayer/Devices/PIC/progP24.cpp \
    HardwareLayer/Devices/AVR/progAVR.cpp \
    HardwareLayer/Devices/readWriteInfo.cpp \
    Libs/strings.cpp \
    Forms/ioCheck.cpp \
    Forms/convert.cpp \
    Forms/icd.cpp \
    Forms/dis_asmble.cpp \
    HardwareLayer/Protcol/icd_protcol.cpp \
    HardwareLayer/Protcol/i2c_spi_protcol.cpp \
    HardwareLayer/fileIO.cpp \
    widgets/scrollTest.cpp \
    HardwareLayer/Devices/AVR/readXMLAVRList.cpp \
    HardwareLayer/Devices/AVR/avrFuse.cpp \
    widgets/fuseSettings/picFuseSettings.cpp \
    HardwareLayer/Devices/PIC/readXMLPIC.cpp \
    Libs/xmlFunctions.cpp
#! [0]
RESOURCES     = AllProgrammer.qrc
#! [0]


FORMS += \
    mainwindow.ui \
    widgets/hexEditor/hexEditor.ui \
    widgets/fuseSettings/fuseSettings.ui \
    widgets/fuseSettings/avrFuseSettings.ui \
    widgets/deviceListWidget.ui \
    Forms/convert.ui \
    Forms/ioCheck.ui \
    Forms/icd.ui \
    Forms/dis_asmble.ui \
    widgets/fuseSettings/picFuseSettings.ui
LIBS += -lsetupapi -ladvapi32 -lws2_32

