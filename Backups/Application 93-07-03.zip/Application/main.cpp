/****************************************************************************
**
** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

//! [0]
#include <QApplication>
/*#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
*/
#include "mainwindow.h"
#include "widgets/hexEditor/hexPlainTextEdit.h"
#include "Forms/ioCheck.h"
#include "HardwareLayer/fileIO.h"
#include "widgets/scrollTest.h"
#include "HardwareLayer/Devices/AVR/readXMLAVRList.h"
#include "HardwareLayer/Devices/PIC/readXMLPIC.h"

int main(int argc, char *argv[])
{
    //Q_INIT_RESOURCE(application);
    QApplication app(argc, argv);
    //app.setOrganizationName("QtProject");
    //app.setApplicationName("Application Example");
    GlobalVariables::getInstance();

    /*QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("Database/data.db");
    bool db_ok = db.open();
    qDebug()<<db_ok;
    QSqlQuery query;
    query.prepare( "SELECT * FROM Students" );
    //query.bindValue( 0, idx ); // assuming idx is an integer/long/QVariant value

    if( !query.exec() )
    {
        qDebug()<<query.lastError();
      // Error Handling, check query.lastError(), probably return
    }

    // Note: if you don't return in case of an error, put this into the else{} part
    while( query.next() )
    {
        qDebug()<<query.value(0).toInt()<<query.value(1).toString()<<query.value(2).toString();
    }

    return 0;
    */
    //ReadXMLAVRList *readXMLAVRList=new ReadXMLAVRList ();
    //readXMLAVRList->ReadXML("ATmega8");
    //return 0;
    //ReadXMLPIC *readXML=new ReadXMLPIC ();
    //readXML->readXML("18F452");
    //return 0;

    //ScrollTest scrollTest;
    //scrollTest.show();
    MainWindow w;
    w.show();
    return app.exec();
}
//! [0]
