#ifndef COMMONVARIABLES_H
#define COMMONVARIABLES_H

#include <QObject>
#include <QAction>
#include "QString"

#include <cstring>
#include <unistd.h>
#include <QPlainTextEdit>
#include <getopt.h>

#include "HardwareLayer/Devices/progDevice.h"
#include "HardwareLayer/Devices/Memory/progEEPROM.h"
#include "HardwareLayer/Devices/AVR/progAVR.h"
#include "HardwareLayer/Devices/PIC/progP12.h"
#include "HardwareLayer/Devices/PIC/progP16.h"
#include "HardwareLayer/Devices/PIC/progP18.h"
#include "HardwareLayer/Devices/PIC/progP24.h"
#include "Libs/strings.h"


namespace Family
{
    enum Family {PIC12,PIC16,PIC18,PIC24,AVR,I2CEE,SPIEE,UWEE,OWEE,UNIOEE};
}
namespace ReadFunctions
{
    enum ReadFunctions{ Read12F5xx, Read16Fxxx, Read16F1xxx, Read18Fx, Read24Fx, Read24Ex, ReadI2C, Read93x, Read25xx, ReadOneWireMem, ReadDS1820, Read11xx, ReadAT, ReadAT_HV};
}
namespace WriteFunctions
{
    enum WriteFunctions{Write12F5xx, Write12C5xx, Write12F6xx, Write12F61x, Write12F62x, Write16F7x, Write16F71x, Write16F72x, Write16F62x, Write16F8x, Write16F81x, Write16F87x, Write16F87xA, Write16F88x, Write16F1xxx, Write18Fx,
                    Write24Fx, Write24Ex, WriteI2C, Write93Sx, Write93Cx, Write25xx, WriteOneWireMem, Write11xx, WriteAT, WriteATmega, WriteAT_HV};
}

//using namespace Ui;
class GlobalVariables : public QObject
{
    Q_OBJECT
public:


    static GlobalVariables *getInstance();
    static USBTools *usb;
    static QPlainTextEdit *txtLog;
    static ProgEEPROM *progEEPROM;
    static ProgAVR *progAVR;
    static ProgP12 *progP12;
    static ProgP16 *progP16;
    static ProgP18 *progP18;
    static ProgP24 *progP24;
    static Strings strings;
    static bool saveLog;
    static void printMessage(QString msg);
    static void printMessage1(QString format, int p1);
    static void printMessage1(QString msg, const char *p1);
    static void printMessage2(QString msg, int p1, int p2);
    static void printMessage3(QString msg, double p1, int p2, int p3);
    static void printMessage3(QString msg, char *p1, int p2, int p3);
    static void printMessage4(QString msg, int p1, int p2, int p3, int p4);

    static void	PrintStatusSetup(); //only needed for console version
    static void  PrintStatusEnd();     //only needed for console version
    static void  PrintStatusClear();   //gtk_statusbar_push(GTK_STATUSBAR(status_bar),statusID,"");




    static void printMessage(char *msg);


private:
    explicit GlobalVariables(QObject *parent = 0);
    static GlobalVariables * globalVariables;
    static QAction *Act1;

signals:
  //void  PrintStatus(QString msg1 ,int j,int i);
public slots:
    
};

#endif // COMMONVARIABLES_H
