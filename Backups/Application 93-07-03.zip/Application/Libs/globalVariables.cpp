#include "globalVariables.h"




USBTools    *GlobalVariables::usb;
ProgEEPROM  *GlobalVariables::progEEPROM;
ProgAVR     *GlobalVariables::progAVR;
ProgP12     *GlobalVariables::progP12;
ProgP16     *GlobalVariables::progP16;
ProgP18     *GlobalVariables::progP18;
ProgP24     *GlobalVariables::progP24;
Strings      GlobalVariables::strings;
bool         GlobalVariables::saveLog;

QPlainTextEdit *GlobalVariables::txtLog;

GlobalVariables *GlobalVariables::globalVariables;

GlobalVariables::GlobalVariables(QObject *parent) :
    QObject(parent)
{
    usb = new USBTools();
    progEEPROM = new ProgEEPROM(usb, this);
    progAVR = new ProgAVR(usb, this);
    progP12 = new ProgP12(usb, this);
    progP16 = new ProgP16(usb, this);
    progP18 = new ProgP18(usb, this);
    progP24 = new ProgP24(usb, this);
    saveLog=false;
    txtLog=NULL;
}


GlobalVariables *GlobalVariables::getInstance()
{
    if(globalVariables==NULL)
    {
        globalVariables = new GlobalVariables();
    }
    return globalVariables;
}

void GlobalVariables::printMessage(QString msg)
{
    qDebug()<<msg;
    if(txtLog!=NULL)
    {
        txtLog->appendPlainText(msg.replace("\n\n","\n"));
    }
}

void GlobalVariables::printMessage(char *msg)
{

    QString str;
    str.sprintf("%s",msg);
    printMessage(str);
}

void GlobalVariables::printMessage1(QString msg, int p1)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1);
    printMessage(str);
}

void GlobalVariables::printMessage1(QString msg, const char *p1)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1);
    printMessage(str);
}

void GlobalVariables::printMessage2(QString msg, int p1, int p2)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1,p2);
    printMessage(str);
}

void GlobalVariables::printMessage3(QString msg, double p1, int p2, int p3)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1,p2,p3);
    printMessage(str);
}

void GlobalVariables::printMessage3(QString msg, char *p1, int p2, int p3)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1,p2,p3);
    printMessage(str);
}

void GlobalVariables::printMessage4(QString msg, int p1, int p2, int p3, int p4)
{
    QString str;
    str.sprintf(msg.toUtf8(), p1,p2,p3,p4);
    printMessage(str);
}

void GlobalVariables::PrintStatusSetup()
{

}

void GlobalVariables::PrintStatusEnd()
{
}

void GlobalVariables::PrintStatusClear()
{
}
