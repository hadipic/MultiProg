#ifndef FILEIO_H
#define FILEIO_H

#include <QObject>
#include "usbTools.h"

class FileIO : public QObject
{
    Q_OBJECT
public:
    explicit FileIO(QObject *parent = 0);
    USBTools *usb;

    int load(QString dev, QString loadfile);
    int load(char *dev, char *loadfile);

    int htoi(const char *hex, int length);

    int save(QString dev, QString loadfile);
    void save(char *dev, char *savefile);


    int loadEE(QString dev, QString loadfile);
    void loadEE(char *dev, char *loadfile);

    int saveEE(QString dev, QString loadfile);
    void saveEE(char *dev, char *savefile);


private:

signals:
    
public slots:
    
};


#endif // FILEIO_H
