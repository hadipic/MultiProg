#ifndef READWRITEINFO_H
#define READWRITEINFO_H

#include "Libs/globalVariables.h"
#include <QObject>
#include <QDebug>

#include <HardwareLayer/usbTools.h>





class ReadWriteInfo : public QObject

 {
//Q_OBJECT
public:

    ReadWriteInfo();

    ReadWriteInfo(int family, double HV, int V33, int readFunctionIndex, qint64 memoryFlashSize, qint64 memoryEESize, QList<int> readParam, int resArea, int writeFunctionIndex, QList<int> writeParam, double writeParamD);
    int family;
    int readFunctionIndex;
    int writeFunctionIndex;
    double HV;                  //High voltage value (-1= turn off HV)
    int V33;                    //3.3V regulator required (0=not required)
    qint64 memoryFlashSize;
    qint64 memoryEESize;
    qint64 addresConfig;
    qint64 addresEE;

    bool hasCode;
    bool hasEE;
    bool eeInCode;

    int readParam[2];           //Read function parameters; -10 = NU
    int resArea;                //reserved area size
    int writeParam[6];			//Write function parameters; -10 = NU
    double writeParamD;			//Write function parameter, double
    void read(int ee,int r);
    void write(int ee);
    //AvrFuse * avrFuse;
    // explicit ReadWriteInfo1(USBTools *usb, QObject *parent = 0);


    protected:
  //  USBTools *usb;


};
#endif // READWRITEINFO_H
