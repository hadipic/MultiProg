#include "readXMLPIC.h"
#include "QFile"
#include "QMessageBox"
#include "QDebug"
#include "QDomElement"
#include <QtCore/qmath.h>

ReadXMLPIC::ReadXMLPIC()
{
}

QList<FuseByte> ReadXMLPIC::readXML(QString picName)
{
    QFile *xmlFile = new QFile("XML/PIC/"+picName+".xml");
    QList<FuseByte> fuseConfigs;
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //QMessageBox::critical(this,"Load XML File Problem",
        //                    "Couldn't open xmlfile.xml to load settings for download",
        //                  QMessageBox::Ok);
        return fuseConfigs;
    }
    QXmlStreamReader xmlReader(xmlFile);

    FuseByte *fuseConfig;
    FuseNavigationGroup *group;
    FuseNavigation *navigation;
    int configNumber=0;
    int status=0;
    while(!xmlReader.atEnd() && !xmlReader.hasError())
    {
        // Read next element
        QXmlStreamReader::TokenType token = xmlReader.readNext();

        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument)
        {
            continue;
        }
        //If token is StartElement - read it
        if(token == QXmlStreamReader::StartElement)
        {
            if(xmlReader.name()=="config")
            {
                /*for (int i = 0; i < xmlReader.attributes().count(); ++i)
                {
                    qDebug()<<xmlReader.attributes().at(i).name()<<xmlReader.attributes().at(i).value();
                }
                QString configName=xmlReader.attributes().value("name").toString();
                if(configName=="")
                    configName="Word0";*/
                //if(configNumber)
                    //fuseConfigs.append(fuseConfig);
                fuseConfig = new FuseByte;
                fuseConfigs.append(*fuseConfig);
                delete fuseConfig;
                fuseConfig = &fuseConfigs.last();

                fuseConfig->name=xmlReader.attributes().value("name").toString();
                if(fuseConfig->name=="")
                    fuseConfig->name="Config"+QString::number(configNumber);

                fuseConfig->mask=xmlReader.attributes().value("wmask").toString().mid(2).toUInt(0,16);
                fuseConfig->value=xmlReader.attributes().value("bvalue").toString().mid(2).toUInt(0,16);
                configNumber++;
                status=1;

                //qDebug()<<"microName:"<<microName<<xmlReader.attributes().count();
            }
            if(xmlReader.name()=="mask"&& (status==1 || status==2))
            {
                //if(group.members.count())
                group = new FuseNavigationGroup;
                fuseConfig->navigationGroups.append(*group);
                delete group;
                group=&fuseConfig->navigationGroups.last();

                group->name=xmlReader.attributes().value("name").toString();
                group->mask=xmlReader.attributes().value("value").toString().mid(2).toUInt(0, 16);
                status=2;
            }
            if(xmlReader.name()=="value" && status==2)
            {
                navigation = new FuseNavigation;
                group->members.append(*navigation);
                delete navigation;
                navigation=&group->members.last();
                //navigation.
                navigation->value=xmlReader.attributes().value("value").toString().mid(2).toUInt(0, 16);
                navigation->text=xmlReader.attributes().value("name").toString();
            }
            //fuseConfig.navigationGroups.append(group);

        }

    }
    return fuseConfigs;
}
