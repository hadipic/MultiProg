#ifndef PROGP24_H
#define PROGP24_H
#include "HardwareLayer/Devices/progDevice.h"

class ProgP24 : public ProgDevice
{
    Q_OBJECT
public:
    ProgP24(USBTools *usb, QObject *parent = 0);
    void Read24Fx(int dim,int dim2,int options,int appIDaddr,int executiveArea);
    void Write24Fx(int dim,int dim2,int options,int appIDaddr,int rowSize, double wait);
    void DisplayCODE24F(int dim);
    void DisplayEE24F();
    void Read24Ex(int dim,int dim2,int options,int appIDaddr,int executiveArea);
    void Write24Ex(int dim,int dim2,int options,int appIDaddr,int rowSize, double wait);
    void PIC24_ID(int id);
    void CheckData(int a,int b,int addr,int *err);
private:
    void InitPIC24_ID();
    struct ID24{
        int id;
        char *device;
    } PIC24LIST[268];

signals:
    void onProgressChanged(int step, int max);


};

#endif // PROGP24_H
