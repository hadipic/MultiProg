#ifndef PROGP12_H
#define PROGP12_H
#include "HardwareLayer/Devices/progDevice.h"

class ProgP12 : public ProgDevice
{
public:
    ProgP12(USBTools *usb, QObject *parent = 0);
    void Read12F5xx(int dim, int dim2);
    void Write12F5xx(int dim,int OscAddr);
    void Write12C5xx(int dim,int dummy);

    int use_osccal=1,use_BKosccal=0;
    int saveLog=0,programID=1,MinDly=1,load_osccal=0,load_BKosccal=0;
    int load_calibword=0,max_err=200;

signals:

};

#endif // PROGP12_H
