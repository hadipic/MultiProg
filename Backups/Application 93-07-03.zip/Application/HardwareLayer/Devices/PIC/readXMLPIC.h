#ifndef READXMLPIC_H
#define READXMLPIC_H
#include <QList>
#include <QString>
#include <QXmlStreamReader>

#include "../fuseStruct.h"



class ReadXMLPIC
{
public:
    ReadXMLPIC();
    QList<FuseByte> readXML(QString picName);
};

#endif // READXMLPIC_H
