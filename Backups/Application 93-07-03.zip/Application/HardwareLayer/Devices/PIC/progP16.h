#ifndef PROGP16_H
#define PROGP16_H
#include "HardwareLayer/Devices/progDevice.h"
//#include "HardwareLayer/Devices/readWriteInfo.h"


class ProgP16 : public ProgDevice
{
    Q_OBJECT
public:
    ProgP16(USBTools *usb, QObject *parent = 0);

    //void Read16Fxxx(ReadWriteInfo *deviceInfo, int dim,int dim2,int dim3,int vdd);



    void PIC16_ID(WORD id);
    void Read16Fxxx(int dim,int dim2,int dim3,int vdd);
    void Write12F6xx(int dim,int dim2);
    void Write12F61x(int dim,int d,int d2);
    void Write12F62x(int dim,int dim2);
    void Write16F7x(int dim,int vdd);
    void Write16F71x(int dim,int vdd);
    void Write16F72x(int dim,int d,int d2);
    void Write16F62x (int dim,int dim2);
    void Write16F8x(int dim,int dim2);
    void Write16F81x(int dim,int dim2);
    void Write16F87x(int dim,int dim2);
    void Write16F87xA(int dim,int dim2,int seq);
    void Write16F88x(int dim,int dim2);
    void Read16F1xxx(int dim,int dim2,int dim3,int options);
    void Write16F1xxx(int dim,int dim2,int options);
    void DisplayCODE16F(int size);
    void DisplayEE16F(int size);
    int size,sizeW,sizeEE,sizeCONFIG,sizeUSERID;
private:
    void InitPIC16_ID();
    struct ID16{
        int id;
        char *device;
        int revmask;
    };
    ID16 PIC16LIST[168] ;




public slots:
signals:
};

#endif // PROGP16_H
