#include "readXMLAVRList.h"
#include "QFile"
#include "QMessageBox"
#include "QDebug"
#include "QDomElement"
#include <QtCore/qmath.h>
ReadXMLAVRList::ReadXMLAVRList()
{

}


void ReadXMLAVRList::addNavigations(QXmlStreamReader &xmlReader, FuseByte *fuseByte, int textCount)
{
    quint8 lastMask=0;
    FuseNavigationGroup fuzeNavigationGroup;
    for(int i=0;i<textCount;i++)
    {
        FuseNavigation fuseNavigation;
        XMLFunctions::goToStartElement(xmlReader, "MASK");

        quint8 mask=xmlReader.text().toString().right(2).toUInt(0, 16);

        XMLFunctions::goToStartElement(xmlReader, "VALUE");
        fuseNavigation.value=xmlReader.text().toString().right(2).toUInt(0, 16);

        XMLFunctions::goToStartElement(xmlReader, "TEXT");
        fuseNavigation.text=xmlReader.text().toString();

        qDebug()<<mask<<fuseNavigation.value<<fuseNavigation.text;

        if(mask!=lastMask && fuzeNavigationGroup.members.count()>0)
        {
            fuseByte->navigationGroups.append(fuzeNavigationGroup);
            fuzeNavigationGroup.members.clear();
        }
        fuzeNavigationGroup.members.append(fuseNavigation);
        fuzeNavigationGroup.mask=mask;
        lastMask=mask;
    }
    fuseByte->navigationGroups.append(fuzeNavigationGroup);
}

AvrFuse *ReadXMLAVRList::ReadXML(QString avrName)
{
    AvrFuseType::AvrFuseType status=AvrFuseType::NONE;

    QFile *xmlFile = new QFile("XML/AVR/"+avrName+".xml");
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //QMessageBox::critical(this,"Load XML File Problem",
        //                    "Couldn't open xmlfile.xml to load settings for download",
        //                  QMessageBox::Ok);
        return NULL;
    }
    QXmlStreamReader xmlReader(xmlFile);

    AvrFuse *avrFuze = new AvrFuse();
    FuseByte *fuseByte;

    //Parse the XML until we reach end of it
    QString data="";
    int bitCount=0;
    int textCount=0;

    while(!xmlReader.atEnd() && !xmlReader.hasError())
    {
        // Read next element
        QXmlStreamReader::TokenType token = xmlReader.readNext();

        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument)
        {
            continue;
        }
        //If token is StartElement - read it
        if(token == QXmlStreamReader::StartElement)
        {
            if(xmlReader.name()=="PART_NAME")
            {
                xmlReader.readNext();
                QString microName=xmlReader.text().toString();
                qDebug()<<microName;
            }

            if(xmlReader.name()=="LOCKBIT")
            {
                fuseByte=&avrFuze->lock;
                status=AvrFuseType::FuseLock;
            }

            if(status==AvrFuseType::FuseLock && xmlReader.name()=="NMB_LOCK_BITS")
            {
                xmlReader.readNext();
                bitCount=xmlReader.text().toString().toUInt();
            }

            if(status==AvrFuseType::FuseLock && xmlReader.name()=="NMB_TEXT")
            {
                xmlReader.readNext();
                textCount=xmlReader.text().toString().toUInt();
            }

            if(status==AvrFuseType::FuseLock && textCount>0 && xmlReader.name()=="TEXT1")
            {
                addNavigations(xmlReader, fuseByte, textCount);
                textCount=0;
            }

            if(status==AvrFuseType::FuseLock && bitCount>0 && xmlReader.name().startsWith("LOCKBIT"))
            {
                fuseByte->defualt=0xFF;
                fuseByte->value=fuseByte->defualt;

                BitInfo bitInfo;
                QString tagName="";
                for(int i=0;i<bitCount;i++)
                {
                    if(i>0)
                        XMLFunctions::goToSimilarStartElement(xmlReader, "LOCKBIT");
                    tagName=xmlReader.name().toString();
                    bitInfo.bitNumber=tagName.right(tagName.length()-7).toInt();

                    XMLFunctions::goToStartElement(xmlReader, "NAME");
                    bitInfo.bitName=xmlReader.text().toString();

                    XMLFunctions::goToStartElement(xmlReader, "TEXT");
                    bitInfo.description=xmlReader.text().toString();
                    fuseByte->bitsInfo.append(bitInfo);


                }
                status==AvrFuseType::NONE;
                bitCount=0;
            }

            if(xmlReader.name()=="LOW")
            {
                fuseByte=&avrFuze->low;
                status=AvrFuseType::FuseLow;
            }
            else if(xmlReader.name()=="HIGH")
            {
                fuseByte=&avrFuze->high;
                status=AvrFuseType::FuseHigh;
            }
            else if(xmlReader.name()=="EXTENDED")
            {
                fuseByte=&avrFuze->extend;
                status=AvrFuseType::FuseExtend;
            }


            if((status==AvrFuseType::FuseLow || status==AvrFuseType::FuseHigh || status==AvrFuseType::FuseExtend)
                    && xmlReader.name()=="NMB_FUSE_BITS")
            {
                xmlReader.readNext();
                bitCount=xmlReader.text().toString().toUInt();
            }


            if((status==AvrFuseType::FuseLow || status==AvrFuseType::FuseHigh || status==AvrFuseType::FuseExtend)
                    && xmlReader.name()=="NMB_TEXT")
            {
                xmlReader.readNext();
                textCount=xmlReader.text().toString().toUInt();
            }

        }




        if((status==AvrFuseType::FuseLow || status==AvrFuseType::FuseHigh || status==AvrFuseType::FuseExtend)
                && (bitCount>0))
        {
            quint8 def=0;
            BitInfo bitInfo;
            QString tagName="";

            for(int i=0;i<bitCount;i++)
            {
                XMLFunctions::goToSimilarStartElement(xmlReader, "FUSE");
                tagName=xmlReader.name().toString();
                bitInfo.bitNumber=tagName.right(tagName.length()-4).toInt();

                XMLFunctions::goToStartElement(xmlReader, "NAME");
                bitInfo.bitName=xmlReader.text().toString();

                XMLFunctions::goToStartElement(xmlReader, "TEXT");
                bitInfo.description=xmlReader.text().toString();
                fuseByte->bitsInfo.insert(0, bitInfo);

                if(XMLFunctions::goToStartElement(xmlReader, "DEFAULT", "FUSE"))
                {
                    //def.append(xmlReader.text().toString());
                    if(xmlReader.text().toString()=="1")
                        def+=qPow(2,  bitInfo.bitNumber);
                }
            }
            fuseByte->defualt=def;//.toUInt(0, 2);
            fuseByte->value=fuseByte->defualt;
            bitCount=0;
        }



        if((status==AvrFuseType::FuseLow || status==AvrFuseType::FuseHigh || status==AvrFuseType::FuseExtend)
                && (textCount>0))
        {
            addNavigations(xmlReader, fuseByte, textCount);
            textCount=0;
        }
    }

    if(xmlReader.hasError())
    {
        //QMessageBox::critical(this,
        //                    "xmlFile.xml Parse Error",xmlReader.errorString(),
        //                  QMessageBox::Ok);
        qDebug() <<"Parse Error";
        return avrFuze;
    }

    //close reader and flush file
    xmlReader.clear();
    xmlFile->close();
    return avrFuze;
}
