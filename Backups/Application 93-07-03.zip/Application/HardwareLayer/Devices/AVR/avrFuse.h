#ifndef AVRFUSE_H
#define AVRFUSE_H
#include <QString>
#include <QList>
#include "../fuseStruct.h"

namespace AvrFuseType
{
    enum AvrFuseType{NONE=0, FuseLow, FuseHigh, FuseExtend, FuseLock};
}


class AvrFuse
{
public:
    AvrFuse();
    FuseByte low;
    FuseByte high;
    FuseByte extend;
    FuseByte lock;
    //SaveToJson();
    //ReadFromJson();
};

#endif // AVRFUSE_H
