#ifndef PROGAVR_H
#define PROGAVR_H
#include "HardwareLayer/Devices/progDevice.h"

class ProgAVR : public ProgDevice
{
    Q_OBJECT
public:
    explicit ProgAVR(USBTools *usb, QObject *parent = 0);

    void ReadAT(int dim, int dim2, int options);
    void ReadAT_Fuze(int options, bool readLock=false);

    void ReadAT_HV_Fuze(int options, bool readLock=false);
    void ReadAT_HV(int dim, int dim2, int options);

    void WriteAT(int dim, int dim2);
    void WriteAT_Fuze();

    void WriteATmega(int dim, int dim2, int page, int options);
    void WriteATmega_Fuze(int options);

    void WriteAT_HV(int dim, int dim2, int page, int options);


    void DisplayCODEAVR(int dim);
    void AtmelID(BYTE id[]);
    quint8 AVRlock,AVRfuse,AVRfuse_h,AVRfuse_x;

private:

    void InitAtmelID();
    struct AVRID
    {
        int id;
        char *device;
        quint32 signature;

    }AVRLIST[39];

signals:
    void onProgressChanged(int step, int max);


};

#endif // PROGAVR_H
