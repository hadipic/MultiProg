#include "avrFuse.h"

AvrFuse::AvrFuse()
{
    low.defualt=high.defualt=extend.defualt=lock.defualt=0;
}
