#include "picFuseSettings.h"
#include "ui_picFuseSettings.h"
#include <QComboBox>
#include <QCheckBox>

PicFuseSettings::PicFuseSettings(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PicFuseSettings)
{
    ui->setupUi(this);
}

PicFuseSettings::~PicFuseSettings()
{
    delete ui;
}

void PicFuseSettings::setDeviceInfo(DeviceInfo *deviceInfo)
{
    this->deviceInfo = deviceInfo;
}

void PicFuseSettings::loadPicFuseSettings()
{
    ReadXMLPIC readXMLPIC;
    fuseConfigs=readXMLPIC.readXML(deviceInfo->name);
    if(!fuseConfigs.count())
    {
        GlobalVariables::printMessage("file "+deviceInfo->name+".xml not find");
        return;
    }
    ui->lstConfigs->clear();
    for (int i = 0; i < fuseConfigs.count(); ++i)
    {
        ui->lstConfigs->addItem(fuseConfigs.at(i).name);
    }
    on_lstConfigs_currentRowChanged(0);
}

void PicFuseSettings::on_lstConfigs_currentRowChanged(int currentRow)
{

    /*for (int i = 0; i < ui->scrollAreaAVRNavigation->children().count(); ++i)
    {
        QObject *object= ui->scrollAreaAVRNavigation->children().at(i);
        qDebug()<<"className"<<object->metaObject()->className();
        if(object->metaObject()->className()!="QScrollArea")
        {
            delete object;
            object=NULL;
        }

    }*/
    FuseByte fuseConfig=fuseConfigs.at(currentRow);
    for (int i = 0; i < fuseConfig.navigationGroups.count(); ++i)
    {
        int memberCount=fuseConfig.navigationGroups.at(i).members.count();
        if(memberCount>=2)
        {
            QComboBox *combobox=new QComboBox(ui->scrollAreaAVRNavigation);
            ui->verticalLayout->addWidget(combobox);
            quint8 mask = fuseConfig.navigationGroups.at(i).mask;
            //avrNavComboBoxes.append(ComboBoxNav(combobox, mask, fuseType));
            //QList<QCheckBox*> fuseCheckBoxes;
            //connect(combobox, SIGNAL(currentIndexChanged(int)), this, SLOT(onAvrNavComboBoxChanged(int)));
            for (int j = 0; j < memberCount; ++j)
            {
                quint8 value=fuseConfig.navigationGroups.at(i).members.at(j).value;
                combobox->addItem(QString::number(value,2)+":"+ fuseConfig.navigationGroups.at(i).members.at(j).text, value);
            }
        }

    }
    for (int i = 0; i < fuseConfig.navigationGroups.count(); ++i)
    {
        int memberCount=fuseConfig.navigationGroups.at(i).members.count();
        if(memberCount==2)
        {
            QCheckBox *checkBoxNav=new QCheckBox(ui->scrollAreaAVRNavigation);

            checkBoxNav->setText(fuseConfig.navigationGroups.at(i).name);
            //connect(checkBoxNav, SIGNAL(clicked()), this, SLOT(onAvrNavCheckBoxChanged()));

            ui->verticalLayout->addWidget(checkBoxNav);
        }
    }


}
