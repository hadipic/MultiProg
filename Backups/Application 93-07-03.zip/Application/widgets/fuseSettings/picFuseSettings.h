#ifndef PICFUSESETTINGS_H
#define PICFUSESETTINGS_H
#include <QWidget>
#include "HardwareLayer/Devices/devices.h"
#include "HardwareLayer/Devices/PIC/readXMLPIC.h"


namespace Ui {
class PicFuseSettings;
}

class PicFuseSettings : public QWidget
{
    Q_OBJECT
    
public:
    explicit PicFuseSettings(QWidget *parent = 0);
    ~PicFuseSettings();
    void setDeviceInfo(DeviceInfo *deviceInfo);

    void loadPicFuseSettings();
private slots:
    void on_lstConfigs_currentRowChanged(int currentRow);

private:
    DeviceInfo *deviceInfo;
    Ui::PicFuseSettings *ui;
    QList<FuseByte> fuseConfigs;
};

#endif // PICFUSESETTINGS_H
