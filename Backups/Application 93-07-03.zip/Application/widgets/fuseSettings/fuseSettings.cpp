#include "fuseSettings.h"
#include "Libs/globalVariables.h"
#include <QSettings>
#include <qmath.h>

FuseSettings::FuseSettings(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FuseSettings)
{
    ui->setupUi(this);

}

FuseSettings::~FuseSettings()
{
    delete ui;

}

Ui::FuseSettings *FuseSettings::getUi()
{
    return ui;
}

void FuseSettings::setDeviceInfo(DeviceInfo *deviceInfo)
{
    this->deviceInfo=deviceInfo;
}

void FuseSettings::loadAVRFuseSettings()
{
    ui->pageAvrFuseSettings->setDeviceInfo(deviceInfo);
    ui->pageAvrFuseSettings->loadAVRFuseSettings();
}

void FuseSettings::loadPICFuseSettings()
{
    ui->pagePicFuseSettings->setDeviceInfo(deviceInfo);
    ui->pagePicFuseSettings->loadPicFuseSettings();
}
