#ifndef FUZESETTINGS_H
#define FUZESETTINGS_H

#include <QWidget>
#include <QList>
#include <QComboBox>
#include "ui_fuseSettings.h"
#include "avrFuseSettings.h"

namespace Ui
{
class FuseSettings;
}

class FuseSettings : public QWidget
{
	Q_OBJECT
public:
    explicit FuseSettings(QWidget *parent = 0);
    ~FuseSettings();
    Ui::FuseSettings *getUi();
    Ui::FuseSettings *ui;
    void setDeviceInfo(DeviceInfo *deviceInfo);

    void loadAVRFuseSettings();
    void loadPICFuseSettings();

private:
    DeviceInfo *deviceInfo;
public slots:
private slots:

};

#endif // FUZESETTINGS_H
