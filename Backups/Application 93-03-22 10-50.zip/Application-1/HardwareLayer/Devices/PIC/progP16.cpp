#include "progP16.h"

ProgP16::ProgP16(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{
}

void ProgP16::Read16Fxxx(int dim,int dim2,int dim3,int vdd)
{


  // usb->StartHVReg1(134);
    usb->StartHVReg(13.1);

    vdd=1;


    int k=0,k2=0,z=0,i,j,ee2200=0;
    char s[512],t[256],*aux;
    if(dim2<0){
        dim2=-dim2;
        ee2200=1;
    }
    if(dim>0x2000||dim<0){
        //PrintMessage(strings[S_CodeLim]);	//"Code size exceeds limits\r\n"
        return;
    }
    if(dim2>0x400||dim2<0){		//Max 1K
        //PrintMessage(strings[S_EELim]);	//"EEPROM size exceeds limits\r\n"
        return;
    }
    if(dim3>0x100||dim3<0){
      //  PrintMessage(strings[S_ConfigLim]);	//"Config area size exceeds limits\r\n"
        return;
    }
    if(dim3<8)dim3=8;
    //if(saveLog){
   //     OpenLogFile();	//"log.txt"
    //    fprintf(logfile,"Read16Fxxx(%d,%d,%d,%d)\n",dim,dim2,dim3,vdd);
    //}
    sizeW=0x2100+dim2;
    if(usb->memCODE_W) free(usb->memCODE_W);
    usb->memCODE_W=(WORD*)malloc(sizeof(WORD)*sizeW);
    unsigned int start=GetTickCount();
    usb->bufferU[0]=0;
    j=1;
    usb->bufferU[j++]=SET_PARAMETER;
    usb->bufferU[j++]=SET_T1T2;
    usb->bufferU[j++]=1;						//T1=1u
    usb->bufferU[j++]=100;					//T2=100u
    usb->bufferU[j++]=SET_PARAMETER;
    usb->bufferU[j++]=SET_T3;
    usb->bufferU[j++]=2000>>8;
    usb->bufferU[j++]=2000&0xff;
    usb->bufferU[j++]=EN_VPP_VCC;		//enter program mode
    usb->bufferU[j++]=0x0;
    usb->bufferU[j++]=SET_CK_D;
    usb->bufferU[j++]=0x0;
    if(vdd==0){						//VPP before VDD
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=4;				//VPP
        usb->bufferU[j++]=NOP;
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=0x5;			//VDD+VPP
    }
    else if(vdd==1){				//VDD before VPP with delay 50ms
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=1;				//VDD
        usb->bufferU[j++]=SET_PARAMETER;
        usb->bufferU[j++]=SET_T3;
        usb->bufferU[j++]=25000>>8;
        usb->bufferU[j++]=25000&0xff;
        usb->bufferU[j++]=WAIT_T3;
        usb->bufferU[j++]=WAIT_T3;
        usb->bufferU[j++]=SET_PARAMETER;
        usb->bufferU[j++]=SET_T3;
        usb->bufferU[j++]=2000>>8;
        usb->bufferU[j++]=2000&0xff;
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=0x5;			//VDD+VPP
    }
    else if(vdd==2){				//VDD before VPP without delay
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=1;				//VDD
        usb->bufferU[j++]=EN_VPP_VCC;
        usb->bufferU[j++]=0x5;			//VDD+VPP
    }
    usb->bufferU[j++]=FLUSH;
    for(;j<usb->DIMBUF;j++) usb->bufferU[j]=0x0;
    usb->Write();
    usb->msDelay(2);
    if(vdd) usb->msDelay(50);
    usb->read();
    //if(saveLog)WriteLogIO();
//****************** usb->read code ********************
   // PrintMessage(strings[S_CodeReading1]);		//read code ...
   // PrintStatusSetup();
    for(i=0,j=1;i<dim;i++){
        usb->bufferU[j++]=READ_DATA_PROG;
        usb->bufferU[j++]=INC_ADDR;
        if(j>usb->DIMBUF*2/4-2||i==dim-1){		//2B cmd -> 4B data
            usb->bufferU[j++]=FLUSH;
            for(;j<usb->DIMBUF;j++) usb->bufferU[j]=0x0;
            usb->Write();
            usb->msDelay(5);
            usb->read();
            for(z=1;z<usb->DIMBUF-2;z++){
                if(usb->bufferI[z]==READ_DATA_PROG){
                    usb->memCODE_W[k++]=(usb->bufferI[z+1]<<8)+usb->bufferI[z+2];
                    z+=2;
                }
            }
           // PrintStatus(strings[S_CodeReading],i*100/(dim+dim2+dim3),i);	//"Read: %d%%, addr. %03X"
            j=1;
            //if(saveLog){
            //    fprintf(logfile,strings[S_Log7],i,i,k,k);	//"i=%d(0x%X), k=%d(0x%X)\n"
            //    WriteLogIO();
            //}
        }
    }
    //PrintStatusEnd();
    //if(k!=dim){
       // PrintMessage("\r\n");
      //  PrintMessage2(strings[S_ReadCodeErr],dim,k);	//"Error reading code area, requested %d words, read %d\r\n"
    //}
   // else PrintMessage(strings[S_Compl]);
    for(i=k;i<0x2000;i++) usb->memCODE_W[i]=0x3fff;
//****************** read config area ********************
   // PrintMessage(strings[S_Read_CONFIG_A]);		//read config ...
    usb->bufferU[j++]=LOAD_CONF;			//counter at 0x2000
    usb->bufferU[j++]=0xFF;				//fake config
    usb->bufferU[j++]=0xFF;				//fake config
    for(i=0x2000;i<0x2000+dim3;i++){		//Config
        usb->bufferU[j++]=READ_DATA_PROG;
        usb->bufferU[j++]=INC_ADDR;
        if(j>usb->DIMBUF*2/4-2||i==0x2000+dim3-1){		//2B cmd -> 4B data
            usb->bufferU[j++]=FLUSH;
            for(;j<usb->DIMBUF;j++) usb->bufferU[j]=0x0;
            usb->Write();
            usb->msDelay(5);
            usb->read();
            for(z=1;z<usb->DIMBUF-2;z++){
                if(usb->bufferI[z]==READ_DATA_PROG){
                    usb->memCODE_W[0x2000+k2++]=(usb->bufferI[z+1]<<8)+usb->bufferI[z+2];
                    z+=2;
                }
            }
           // PrintStatus(strings[S_CodeReading],(i-0x2000+dim)*100/(dim+dim2+dim3),i);	//"Read: %d%%, addr. %03X"
            j=1;
           // if(saveLog){
            //    fprintf(logfile,strings[S_Log7],i,i,k2,k2);	//"i=%d(0x%X), k=%d(0x%X)\n"
            //    WriteLogIO();
            //}
        }
    }
   // if(k2!=dim3){
   //     PrintMessage("\r\n");
   //     PrintMessage2(strings[S_ConfigErr],dim3,k2);	//"Error reading config area, requested %d words, read %d\r\n"
   // }
   // else PrintMessage(strings[S_Compl]);
    for(i=0x2000+k2;i<0x2000+dim3;i++) usb->memCODE_W[i]=0x3fff;
//****************** read eeprom ********************
    if(dim2){
       // PrintMessage(strings[S_ReadEE]);		//Read EEPROM ...
       // PrintStatusSetup();
        if(ee2200){		//eeprom a 0x2200
            usb->bufferU[j++]=INC_ADDR_N;
            usb->bufferU[j++]=0xFF;
            usb->bufferU[j++]=INC_ADDR;
        }
        usb->bufferU[j++]=INC_ADDR_N;
        usb->bufferU[j++]=0x100-dim3;
        for(k2=0,i=0x2100;i<0x2100+dim2;i++){
            usb->bufferU[j++]=READ_DATA_DATA;
            usb->bufferU[j++]=INC_ADDR;
            if(j>usb->DIMBUF*2/4-2||i==0x2100+dim2-1){		//2B cmd -> 4B data
                usb->bufferU[j++]=FLUSH;
                for(;j<usb->DIMBUF;j++) usb->bufferU[j]=0x0;
                usb->Write();
                usb->msDelay(10);
                usb->read();
                for(z=1;z<usb->DIMBUF-1;z++){
                    if(usb->bufferI[z]==READ_DATA_DATA){
                        usb->memCODE_W[0x2100+k2++]=usb->bufferI[z+1];
                        z++;
                    }
                }
                //PrintStatus(strings[S_CodeReading],(i-0x2100+dim)*100/(dim+dim2+dim3),i);	//"Read: %d%%, addr. %03X"
                j=1;
                //if(saveLog){
                //    fprintf(logfile,strings[S_Log7],i,i,k2,k2);	//"i=%d(0x%X), k=%d(0x%X)\n"
                //    WriteLogIO();
                //}
            }
        }
        //PrintStatusEnd();
        if(k2!=dim2){
          //  PrintMessage("\r\n");
           // PrintMessage2(strings[S_ReadEEErr],dim2,k2);	//"Error reading EE area, ..."
            for(i=0x2100+k2;i<0x2100+dim2;i++) usb->memCODE_W[i]=0x3fff;
        }
        //else PrintMessage(strings[S_Compl]);
    }
    usb->bufferU[j++]=NOP;				//exit program mode
    usb->bufferU[j++]=EN_VPP_VCC;
    usb->bufferU[j++]=1;					//VDD
    usb->bufferU[j++]=EN_VPP_VCC;
    usb->bufferU[j++]=0x0;
    usb->bufferU[j++]=SET_CK_D;
    usb->bufferU[j++]=0x0;
    usb->bufferU[j++]=FLUSH;
    for(;j<usb->DIMBUF;j++) usb->bufferU[j]=0x0;
    usb->Write();
    usb->msDelay(1);
    usb->read();
    unsigned int stop=GetTickCount();
    //PrintStatusClear();			//clear status report
//****************** visualize ********************
    for(i=0;i<4;i+=2){
       // PrintMessage4("ID%d: 0x%04X\tID%d: 0x%04X\r\n",i,usb->memCODE_W[0x2000+i],i+1,usb->memCODE_W[0x2000+i+1]);
    }
  //  PrintMessage1(strings[S_DevID],usb->memCODE_W[0x2006]);	//"DevID: 0x%04X\r\n"
    //if(usb->memCODE_W[0x2005]<0x3FFF) PrintMessage1(strings[S_DevREV],usb->memCODE_W[0x2005]);	//"DevREV: 0x%04X\r\n"
    //PIC16_ID(usb->memCODE_W[0x2006]);
   // PrintMessage1(strings[S_ConfigWord],usb->memCODE_W[0x2007]);	//"Configuration word: 0x%04X\r\n"
    if(dim3>8){
      //  PrintMessage1(strings[S_Config2Cal1],usb->memCODE_W[0x2008]);	//"Config2 or Cal1: 0x%04X\r\n"
    }
    if(dim3>9){
     //   PrintMessage1(strings[S_Calib1_2],usb->memCODE_W[0x2009]);	//"Calibration word 1 or 2: 0x%04X\r\n"
    }
    //PrintMessage(strings[S_CodeMem2]);	//"\r\nCode memory\r\n"
    DisplayCODE16F(dim);
    s[0]=0;
    int valid=0,empty=1;
    if(dim3>8){
        aux=(char*)malloc((dim3/COL+1)*(16+COL*5));
        aux[0]=0;
        empty=1;
      //  PrintMessage(strings[S_ConfigResMem]);	//"\r\nConfig and reserved memory:\r\n"
        for(i=0x2000;i<0x2000+dim3;i+=COL){
            valid=0;
            for(j=i;j<i+COL&&j<0x2000+dim3;j++){
        //        sprintf(t,"%04X ",usb->memCODE_W[j]);
          //      strcat(s,t);
                if(usb->memCODE_W[j]<0x3fff) valid=1;
            }
            if(valid){
            //    sprintf(t,"%04X: %s\r\n",i,s);
                empty=0;
              //  strcat(aux,t);
            }
            s[0]=0;
        }
     //   if(empty) PrintMessage(strings[S_Empty]);	//empty
    //    else PrintMessage(aux);
      //  free(aux);
    }
    if(dim2){
      //  PrintMessage(strings[S_EEMem]);	//"\r\nEEPROM memory:\r\n"
        DisplayEE16F(dim2);
    }
   // PrintMessage1(strings[S_End],(stop-start)/1000.0);	//"\r\nEnd (%.2f s)\r\n"
  //    if(saveLog) CloseLogFile();
  //  PrintStatusClear();			//clear status report


}


void ProgP16::Write12F6xx(int dim,int dim2){}
void ProgP16::Write12F61x(int dim,int d,int d2){}
void ProgP16::Write12F62x(int dim,int dim2){}
void ProgP16::Write16F7x(int dim,int vdd){}
void ProgP16::Write16F71x(int dim,int vdd){}
void ProgP16::Write16F72x(int dim,int d,int d2){}
void ProgP16::Write16F62x (int dim,int dim2){}
void ProgP16::Write16F8x(int dim,int dim2){}
void ProgP16::Write16F81x(int dim,int dim2){}
void ProgP16::Write16F87x(int dim,int dim2){}
void ProgP16::Write16F87xA(int dim,int dim2,int seq){}
void ProgP16::Write16F88x(int dim,int dim2){}
void ProgP16::Read16F1xxx(int dim,int dim2,int dim3,int options)
{
    qDebug()<<"PIC 16 Read16F1xxx";

}
void ProgP16::Write16F1xxx(int dim,int dim2,int options)
{
    qDebug()<<"PIC 16 Write16F1xxx";
}
void ProgP16::DisplayCODE16F(int size){}
void ProgP16::DisplayEE16F(int size){}
