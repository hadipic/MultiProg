#include "progP24.h"

ProgP24::ProgP24(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{
}
void ProgP24::Read24Fx(int dim,int dim2,int options,int appIDaddr,int executiveArea){}
void ProgP24::Write24Fx(int dim,int dim2,int options,int appIDaddr,int rowSize, double wait){}
void ProgP24::DisplayCODE24F(int dim){}
void ProgP24::DisplayEE24F(){}
void ProgP24::Read24Ex(int dim,int dim2,int options,int appIDaddr,int executiveArea){}
void ProgP24::Write24Ex(int dim,int dim2,int options,int appIDaddr,int rowSize, double wait){}


