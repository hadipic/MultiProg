#include "progP12.h"

ProgP12::ProgP12(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{

}

void ProgP12::Read12F5xx(int dim, int dim2)
{
    qDebug()<<"Read12F5xx"<<dim<<dim2;
}

void ProgP12::Write12F5xx(int dim, int OscAddr)
{
    qDebug()<<"Write12F5xx"<<dim<<OscAddr;
}

void ProgP12::Write12C5xx(int dim, int dummy)
{
    qDebug()<<"Write12C5xx"<<dim<<dummy;
}
