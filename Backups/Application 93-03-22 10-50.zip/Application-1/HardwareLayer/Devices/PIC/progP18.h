#ifndef PROGP18_H
#define PROGP18_H
#include "HardwareLayer/Devices/progDevice.h"

class ProgP18 : public ProgDevice
{
public:
    ProgP18(USBTools *usb, QObject *parent = 0);
    void Read18Fx(int dim,int dim2,int options);
    void Write18Fx(int dim,int dim2,int wbuf,int eraseW1,int eraseW2,int options);
    void DisplayCODE18F(int dim);


};

#endif // PROGP18_H
