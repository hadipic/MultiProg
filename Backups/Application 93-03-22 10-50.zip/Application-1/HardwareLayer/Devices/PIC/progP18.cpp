#include "progP18.h"

ProgP18::ProgP18(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{
}
void ProgP18::Read18Fx(int dim,int dim2,int options){}
void ProgP18::Write18Fx(int dim,int dim2,int wbuf,int eraseW1,int eraseW2,int options){}
void ProgP18::DisplayCODE18F(int dim){}

