#ifndef PROGDEVICE_H
#define PROGDEVICE_H

#include <QObject>
#include <HardwareLayer/usbTools.h>
#include <QDebug>

class ProgDevice : public QObject
{
    Q_OBJECT
public:
    explicit ProgDevice(USBTools *usb, QObject *parent = 0);
protected:
    USBTools *usb;
signals:
    
public slots:
    
};

#endif // PROGDEVICE_H
