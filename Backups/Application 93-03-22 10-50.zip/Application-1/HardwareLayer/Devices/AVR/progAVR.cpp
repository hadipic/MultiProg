#include "progAVR.h"

ProgAVR::ProgAVR(USBTools *usb, QObject *parent):ProgDevice(usb, parent)
{
}
void ProgAVR::ReadAT(int dim, int dim2, int options){}
void ProgAVR::ReadAT_HV(int dim, int dim2, int options){}
void ProgAVR::WriteAT(int dim, int dim2){}
void ProgAVR::WriteATmega(int dim, int dim2, int page, int options){}
void ProgAVR::WriteAT_HV(int dim, int dim2, int page, int options){}
void ProgAVR::DisplayCODEAVR(int dim){}
