#ifndef DEVICES_H
#define DEVICES_H

#include <QObject>
#include <QList>
#include <QPair>
#include "Libs/globalVariables.h"
#include "readWriteInfo.h"





class DeviceInfo
{
public:
    QString name;
    ReadWriteInfo *readWriteInfo;
};

class DeviceType
{
    public:
    QString typeName;
    QList<DeviceInfo*> devicesList;
    QList<ReadWriteInfo*> readWriteGroups;

    DeviceInfo *  addDevice(QString deviceName, ReadWriteInfo *readWriteInfo);
};

class DeviceFamily
{
    public:
    QString familyName;
    QString companyName;
    QList<DeviceType*> deviceTypesList;
    DeviceType *  addDeviceType(QString typeName);
};




class Devices : public QObject
{
    Q_OBJECT
public:
    explicit Devices(QObject *parent = 0);
    DeviceFamily *addDeviceFamily(QString familyName, QString companyName);

    QList<DeviceFamily*> deviceFamilyList;
    QList<QPair<QString, DeviceType *> > deviceTypeTable;
    void  addDeviceType(DeviceFamily *deviceFamily, QString typeNameForShow, QString perfixName);
    void  addDevice(QString deviceNames, int family, double HV, int V33,
                    int readFunctionIndex, QString readParam, int resArea,
                    int writeFunctionIndex, QString writeParam, double writeParamD);

signals:
    
public slots:
    
};

#endif // DEVICES_H
