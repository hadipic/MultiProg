#include "readWriteInfo.h"

ReadWriteInfo::ReadWriteInfo()
{
}

ReadWriteInfo::ReadWriteInfo(int family, double HV, int V33, int readFunctionIndex, qint64 memoryFlashSize, qint64 memoryEESize, QList<int> readParam, int resArea, int writeFunctionIndex, QList<int> writeParam, double writeParamD)
{
    this->family=family;
    this->readFunctionIndex=readFunctionIndex;
    this->writeFunctionIndex = writeFunctionIndex;
    this->HV = HV;
    this->V33=V33;
    this->memoryFlashSize = memoryFlashSize;
    this->memoryEESize=memoryEESize;
    for (int i = 0; i < readParam.length(); ++i)
        this->readParam[i]=readParam[i];
    this->resArea=resArea;
    for (int i = 0; i < writeParam.length(); ++i)
        this->writeParam[i]=writeParam[i];
    this->writeParamD;
}

void ReadWriteInfo::read(int ee, int r)
{
    qint64 params[5];
    params[0]=memoryFlashSize;
    params[1]=memoryEESize;
    for(int i=0;i<2;i++)
        params[i+2]=readParam[i];

    if(this->family==Family::PIC12)
    {
        if(r)
            params[1]=resArea;
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read12F5xx:
            GlobalVariables::progP12->Read12F5xx(params[0], params[1]);
            break;
        }
    }
    else if(this->family==Family::PIC16)
    {
        if(r)
            params[2]=resArea;
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read16Fxxx:
            GlobalVariables::progP16->Read16Fxxx(params[0],params[1],params[2],params[3]);
            break;
        case ReadFunctions::Read16F1xxx:
            GlobalVariables::progP16->Read16F1xxx(params[0],params[1],params[2],params[3]);
            break;
        }
    }
    else if(this->family==Family::PIC18)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read18Fx:
            GlobalVariables::progP18->Read18Fx(params[0],params[1],params[2]);
            break;
        }
    }
    else if(this->family==Family::PIC24)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        qint64 res=r?resArea:0;
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read24Ex:
            GlobalVariables::progP24->Read24Ex(params[0],params[1],params[2], params[3], res);
            break;
        case ReadFunctions::Read24Fx:
            GlobalVariables::progP24->Read24Fx(params[0],params[1],params[2], params[3], res);
            break;
        }
    }
    else if(this->family==Family::AVR)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::ReadAT:
            GlobalVariables::progAVR->ReadAT(params[0],params[1],params[2]);
            break;
        case ReadFunctions::ReadAT_HV:
            GlobalVariables::progAVR->ReadAT_HV(params[0],params[1],params[2]);
            break;
        }
    }
    else if(this->family==Family::I2CEE)
    {
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::ReadI2C:
            GlobalVariables::progEEPROM->ReadI2C(params[0],params[1]);
            break;
        }
    }
    else if(this->family==Family::UWEE)
    {
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read93x:
            GlobalVariables::progEEPROM->Read93x(params[0], params[1], params[2]);
            break;
        }
    }
    else if(this->family==Family::SPIEE)
    {
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read25xx:
            GlobalVariables::progEEPROM->Read25xx(params[0]);
            break;
        }
    }
    else if(this->family==Family::OWEE)
    {
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::ReadOneWireMem:
            GlobalVariables::progEEPROM->ReadOneWireMem(params[0], params[1]);
            break;
        case ReadFunctions::ReadDS1820:
            GlobalVariables::progEEPROM->ReadDS1820();
            break;
        }
    }
    else if(this->family==Family::UNIOEE)
    {
        switch (this->readFunctionIndex)
        {
        case ReadFunctions::Read11xx:
            GlobalVariables::progEEPROM->Read11xx(params[0]);
            break;
        }
    }
}

void ReadWriteInfo::write(int ee)
{
    qint64 params[6];
    for(int i=0;i<6;i++)
        params[i]=writeParam[i];

    if(this->family==Family::PIC12)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write12F5xx:
            GlobalVariables::progP12->Write12F5xx(params[0], params[1]);
            break;
        case WriteFunctions::Write12C5xx:
            GlobalVariables::progP12->Write12C5xx(params[0], params[1]);
            break;
        }
    }
    else if(this->family==Family::PIC16)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write16F1xxx:
            GlobalVariables::progP16->Write16F1xxx(params[0],params[1],params[2]);
            break;
        case WriteFunctions::Write16F81x:
            GlobalVariables::progP16->Write16F81x(params[0],params[1]);
            break;
        case WriteFunctions::Write16F87x:
            GlobalVariables::progP16->Write16F87x(params[0],params[1]);
            break;
        case WriteFunctions::Write16F8x:
            GlobalVariables::progP16->Write16F8x (params[0],params[1]);
            break;
        case WriteFunctions::Write12F61x:
            GlobalVariables::progP16->Write12F61x (params[0],params[1],params[2]);
            break;
        case WriteFunctions::Write12F6xx:
            GlobalVariables::progP16->Write12F6xx (params[0],params[1]);
            break;
        case WriteFunctions::Write16F62x:
            GlobalVariables::progP16->Write16F62x (params[0],params[1]);
            break;
        case WriteFunctions::Write16F71x:
            GlobalVariables::progP16->Write16F71x(params[0],params[1]);
            break;
        case WriteFunctions::Write16F72x:
            GlobalVariables::progP16->Write16F72x(params[0],params[1],params[2]);
            break;
        case WriteFunctions::Write16F7x:
            GlobalVariables::progP16->Write16F7x( params[0],params[1]);
            break;
        case WriteFunctions::Write16F87xA:
            GlobalVariables::progP16->Write16F87xA(params[0],params[1],params[2]);
            break;
        case WriteFunctions::Write16F88x:
            GlobalVariables::progP16->Write16F88x(params[0],params[1]);
            break;
        }
    }
    else if(this->family==Family::PIC18)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter       switch (this->writeFunctionIndex)
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write18Fx:
            GlobalVariables::progP18->Write18Fx(params[0],params[1],params[2],params[3],params[4],params[5]);
            break;
        }
    }
    else if(this->family==Family::PIC24)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write24Ex:
            GlobalVariables::progP24->Write24Ex(params[0],params[1],params[2],params[3],params[4], writeParamD);
            break;
        case WriteFunctions::Write24Fx:
            GlobalVariables::progP24->Write24Fx(params[0],params[1],params[2],params[3],params[4], writeParamD);
            break;
        }
    }
    else if(this->family==Family::AVR)
    {
        if(!ee)
            params[1]=0;					//clear eeprom parameter
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::WriteAT:
            GlobalVariables::progAVR->WriteAT(params[0],params[1]);
            break;
        case WriteFunctions::WriteATmega:
            GlobalVariables::progAVR->WriteATmega(params[0],params[1],params[2],params[3]);
            break;
        case WriteFunctions::WriteAT_HV:
            GlobalVariables::progAVR->WriteAT_HV(params[0],params[1],params[2],params[3]);
            break;
        }
    }
    else if(this->family==Family::I2CEE)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::WriteI2C:
            GlobalVariables::progEEPROM->WriteI2C(params[0],params[1],params[2]);
            break;
        }
    }
    else if(this->family==Family::UWEE)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write93Cx:
            GlobalVariables::progEEPROM->Write93Cx(params[0], params[1], params[2]);
            break;
        case WriteFunctions::Write93Sx:
            GlobalVariables::progEEPROM->Write93Sx(params[0], params[1], params[2]);
            break;
        }
    }
    else if(this->family==Family::SPIEE)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write25xx:
            GlobalVariables::progEEPROM->Write25xx(params[0],params[1]);
            break;
        }
    }
    else if(this->family==Family::OWEE)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::WriteOneWireMem:
            GlobalVariables::progEEPROM->WriteOneWireMem(params[0], params[1]);
            break;
        }
    }
    else if(this->family==Family::UNIOEE)
    {
        switch (this->writeFunctionIndex)
        {
        case WriteFunctions::Write11xx:
            GlobalVariables::progEEPROM->Write11xx(params[0],params[1]);
            break;
        }
    }
}
