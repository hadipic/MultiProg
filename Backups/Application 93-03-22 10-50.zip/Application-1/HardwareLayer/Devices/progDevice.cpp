#include "progDevice.h"

ProgDevice::ProgDevice(USBTools *usb, QObject *parent)
{
    this->usb=usb;
}
