#ifndef COMMONFUNCTIONS_H
#define COMMONFUNCTIONS_H

#include <QObject>

class commonFunctions : public QObject
{
    Q_OBJECT
public:
    explicit commonFunctions(QObject *parent = 0);
    void static PrintMessage(char * str);
    quint32 static GetTickCount();
signals:
    
public slots:
    
};

#endif // COMMONFUNCTIONS_H
