#include "commonFunctions.h"

commonFunctions::commonFunctions(QObject *parent) :
    QObject(parent)
{
}

void commonFunctions::PrintMessage(char *str)
{

}

quint32 commonFunctions::GetTickCount()
{
    struct timeb now;
    ftime(&now);
    return now.time*1000+now.millitm;
}
