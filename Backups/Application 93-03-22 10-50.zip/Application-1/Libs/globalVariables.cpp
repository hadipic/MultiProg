#include "globalVariables.h"

USBTools *GlobalVariables::usb;
ProgEEPROM *GlobalVariables::progEEPROM;
ProgAVR *GlobalVariables::progAVR;
ProgP12    *GlobalVariables::progP12;
ProgP16    *GlobalVariables::progP16;
ProgP18    *GlobalVariables::progP18;
ProgP24    *GlobalVariables::progP24;

GlobalVariables *GlobalVariables::globalVariables;

GlobalVariables::GlobalVariables(QObject *parent) :
    QObject(parent)
{
    usb = new USBTools();
    progEEPROM = new ProgEEPROM(usb, this);
    progAVR = new ProgAVR(usb, this);
    progP12 = new ProgP12(usb, this);
    progP16 = new ProgP16(usb, this);
    progP18 = new ProgP18(usb, this);
    progP24 = new ProgP24(usb, this);
}


GlobalVariables *GlobalVariables::getInstance()
{
    if(globalVariables==NULL)
    {
        globalVariables = new GlobalVariables();
    }
    return globalVariables;
}

void GlobalVariables::printMessage(QString msg)
{
    qDebug()<<msg;
}

void GlobalVariables::printMessage(char *msg)
{
    qDebug()<<msg;
}

