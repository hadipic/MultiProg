QT += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = OpenProgrammer
TEMPLATE = app

HEADERS       = \
    mainwindow.h \
    HardwareLayer/usbTools.h \
    HardwareLayer/instructions.h \
    HardwareLayer/Devices/Memory/progEEPROM.h \
    Libs/commonFunctions.h \
    widgets/hexEditor/hexPlainTextEdit.h \
    widgets/hexEditor/hexEditor.h \
    widgets/hexEditor/asciiPlainTextEdit.h \
    widgets/fuzeSettings.h \
    HardwareLayer/Devices/devices.h \
    widgets/deviceListWidget.h \
    HardwareLayer/Devices/progDevice.h \
    Libs/globalVariables.h \
    HardwareLayer/Devices/PIC/progP12.h \
    HardwareLayer/Devices/PIC/progP16.h \
    HardwareLayer/Devices/PIC/progP18.h \
    HardwareLayer/Devices/PIC/progP24.h \
    HardwareLayer/Devices/AVR/progAVR.h \
    HardwareLayer/Devices/readWriteInfo.h
SOURCES       = main.cpp \
    mainwindow.cpp \
    HardwareLayer/usbTools.cpp \
    HardwareLayer/Devices/Memory/progEEPROM.cpp \
    Libs/commonFunctions.cpp \
    widgets/hexEditor/hexPlainTextEdit.cpp \
    widgets/hexEditor/hexEditor.cpp \
    widgets/hexEditor/asciiPlainTextEdit.cpp \
    widgets/fuzeSettings.cpp \
    HardwareLayer/Devices/devices.cpp \
    widgets/deviceListWidget.cpp \
    HardwareLayer/Devices/progDevice.cpp \
    Libs/globalVariables.cpp \
    HardwareLayer/Devices/PIC/progP12.cpp \
    HardwareLayer/Devices/PIC/progP16.cpp \
    HardwareLayer/Devices/PIC/progP18.cpp \
    HardwareLayer/Devices/PIC/progP24.cpp \
    HardwareLayer/Devices/AVR/progAVR.cpp \
    HardwareLayer/Devices/readWriteInfo.cpp
#! [0]
RESOURCES     = AllProgrammer.qrc
#! [0]


FORMS += \
    mainwindow.ui \
    widgets/hexEditor/hexEditor.ui \
    widgets/fuzeSettings.ui \
    widgets/deviceListWidget.ui
LIBS += -lsetupapi -ladvapi32 -lws2_32

