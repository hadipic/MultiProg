#ifndef HEXEDITOR_H
#define HEXEDITOR_H

#include <QWidget>

#include <QObject>
#include <QPlainTextEdit>
#include <QEvent>
#include <QString>

namespace Ui {
class HexEditor;
}

class HexEditor : public QWidget
{
    Q_OBJECT
    
public:
    explicit HexEditor(QWidget *parent = 0);
    ~HexEditor();
    unsigned char *buffer;
    bool eventFilter(QObject *obj, QEvent *event);
    void loadFile(QString address);
    void loadFromDevice(unsigned char * data, int len);
    void loadFromDevice(quint16 * data, int len);
    quint8 bitLength();
    quint8 byteLength();

    void setBitLength(int length);

    QChar hexToAscii(QString hexStr);
    QString asciiToHex(QChar ch);
    quint32 size();
    void setSize(quint32 size);
private slots:


    void on_asciiTextEdit_textChanged();
    void on_hexTextEdit_cursorPositionChanged();
    void on_hexTextEdit_selectionChanged();
    void on_asciiTextEdit_selectionChanged();
    void on_asciiTextEdit_cursorPositionChanged();
    void on_hexTextEdit_textChanged();
    void on_hexTextEdit_copyAvailable(bool b);
    void on_hexTextEdit_blockCountChanged(int newBlockCount);

private:
    Ui::HexEditor *ui;
    int lastHexPosition;
    int lastAsciiPosition;
    bool loadLine(QString line, int &lineNumber);
    bool otherPosChangeSignal;
    bool busyToLoad;
    quint32 index;
    quint32 _size;
    int hexPosToAsciiPos(int pos);

    int asciiPosToHexPos(int pos);
    bool debug;
    QString emptyHexLine;
    QString emptyAsciiLine;
    void makeEmptyLines();
    quint8 _columnCount;

};

#endif HEXEDITOR_H
